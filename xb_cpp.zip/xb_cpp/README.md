# RDKC XB C++ MVP

Gateway-side C++ starter for the RDKC AI search flow. This is intentionally
small and dependency-light so it can be moved into an RDK/XB build before we add
heavier detector runtimes.

The first milestone is not full object recognition. It is the gateway-native
event pipeline:

1. Initialize XB-safe folders.
2. Read sampled grayscale frames from a motion clip.
3. Detect motion windows.
4. Write event metadata as JSONL.
5. Search indexed metadata from a simple query.

Later, the `index-frames` command can be fed labels from NCNN/TFLite/ONNX
detectors, for example `person,bag,vehicle`.

## Build

On XB or in the RDK target toolchain:

```sh
cd xb_cpp
make
```

If using a cross compiler:

```sh
make CXX=aarch64-linux-gnu-g++
```

To enable ONNX model inspection and future YOLO inference wiring, build with
ONNX Runtime:

```sh
make RDKC_ENABLE_ONNXRUNTIME=1 ONNXRUNTIME_ROOT=/opt/onnxruntime
```

If using a cross compiler with ONNX Runtime staged for the target:

```sh
make CXX=aarch64-linux-gnu-g++ RDKC_ENABLE_ONNXRUNTIME=1 ONNXRUNTIME_ROOT=/path/to/aarch64/onnxruntime
```

## Commands

```sh
./build/rdkc_xb_ai init
./build/rdkc_xb_ai health
./build/rdkc_xb_ai index-frames --frames /tmp/rdkc_ai/frames --camera-id front-door --objects person,bag --event person_with_bag
./build/rdkc_xb_ai inspect-model --model /data/rdkc_ai/models/yolo11n.onnx
./build/rdkc_xb_ai search --query "person carrying bag"
```

Default paths:

- Persistent data: `/data/rdkc_ai`
- Runtime/temp data: `/tmp/rdkc_ai`
- Event index: `/data/rdkc_ai/events/events.jsonl`

For local PC testing, override paths:

```sh
./build/rdkc_xb_ai init --data-root data/xb_cpp --runtime-root data/xb_cpp/tmp
./build/rdkc_xb_ai index-frames --frames data/pgm_frames --data-root data/xb_cpp --runtime-root data/xb_cpp/tmp
```

## Frame Input

`index-frames` currently accepts `.pgm` grayscale frames. On XB, extract frames
from a camera clip using the platform media path, FFmpeg, or GStreamer, then pass
the frame folder here.

Example with FFmpeg when available:

```sh
mkdir -p /tmp/rdkc_ai/frames
ffmpeg -i /tmp/rdkc_ai/clips/frontdoor.mp4 -vf fps=1,format=gray /tmp/rdkc_ai/frames/frame_%05d.pgm
```

## ONNX Model Inspection

`inspect-model` is the C++ equivalent of this Python check:

```python
import onnx
m = onnx.load("yolo.onnx")
print(len(m.graph.input), len(m.graph.output))
```

It uses ONNX Runtime instead of Python `onnx`, because the gateway-side path is
C++:

```sh
./build/rdkc_xb_ai inspect-model --model /data/rdkc_ai/models/yolo11n.onnx
```

Expected output is similar to:

```text
Model: /data/rdkc_ai/models/yolo11n.onnx
Inputs: 1
  images shape=[1, 3, 640, 640] element_type=1
Outputs: 1
  output0 shape=[1, 84, 8400] element_type=1
```

These names and shapes are what the next C++ YOLO inference step needs when it
feeds OpenCV/GStreamer frames into the model and reads detection tensors back.
