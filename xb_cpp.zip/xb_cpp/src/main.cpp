#include <algorithm>
#include <chrono>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <regex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include <filesystem>

#ifdef RDKC_ENABLE_ONNXRUNTIME
#include <onnxruntime_cxx_api.h>
#endif

namespace fs = std::filesystem;

namespace {

struct Paths {
    fs::path data_root = "/data/rdkc_ai";
    fs::path runtime_root = "/tmp/rdkc_ai";

    fs::path events_path() const { return data_root / "events" / "events.jsonl"; }
    fs::path thumbs_dir() const { return runtime_root / "thumbs"; }
    fs::path frames_dir() const { return runtime_root / "frames"; }
};

struct Options {
    std::map<std::string, std::string> values;
    std::vector<std::string> positional;

    bool has(const std::string& key) const {
        return values.find(key) != values.end();
    }

    std::string get(const std::string& key, const std::string& fallback = "") const {
        auto it = values.find(key);
        return it == values.end() ? fallback : it->second;
    }
};

struct Frame {
    int width = 0;
    int height = 0;
    std::vector<uint8_t> pixels;
};

struct Event {
    std::string event_id;
    std::string camera_id;
    std::string source;
    double start_time_s = 0.0;
    double end_time_s = 0.0;
    std::vector<std::string> objects;
    std::string action = "motion";
    double confidence = 0.0;
    std::string thumbnail_path;
};

std::string now_iso_compact() {
    const auto now = std::chrono::system_clock::now();
    const std::time_t t = std::chrono::system_clock::to_time_t(now);
    std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    std::ostringstream out;
    out << std::put_time(&tm, "%Y%m%dT%H%M%S");
    return out.str();
}

std::string escape_json(const std::string& input) {
    std::ostringstream out;
    for (char ch : input) {
        switch (ch) {
            case '"': out << "\\\""; break;
            case '\\': out << "\\\\"; break;
            case '\n': out << "\\n"; break;
            case '\r': out << "\\r"; break;
            case '\t': out << "\\t"; break;
            default:
                if (static_cast<unsigned char>(ch) < 0x20) {
                    out << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                        << static_cast<int>(static_cast<unsigned char>(ch));
                } else {
                    out << ch;
                }
        }
    }
    return out.str();
}

std::string to_json_array(const std::vector<std::string>& values) {
    std::ostringstream out;
    out << "[";
    for (size_t i = 0; i < values.size(); ++i) {
        if (i) out << ",";
        out << "\"" << escape_json(values[i]) << "\"";
    }
    out << "]";
    return out.str();
}

std::string event_to_json(const Event& event) {
    std::ostringstream out;
    out << "{";
    out << "\"event_id\":\"" << escape_json(event.event_id) << "\",";
    out << "\"camera_id\":\"" << escape_json(event.camera_id) << "\",";
    out << "\"source\":\"" << escape_json(event.source) << "\",";
    out << "\"start_time_s\":" << std::fixed << std::setprecision(2) << event.start_time_s << ",";
    out << "\"end_time_s\":" << std::fixed << std::setprecision(2) << event.end_time_s << ",";
    out << "\"objects\":" << to_json_array(event.objects) << ",";
    out << "\"action\":\"" << escape_json(event.action) << "\",";
    out << "\"confidence\":" << std::fixed << std::setprecision(3) << event.confidence << ",";
    out << "\"thumbnail_path\":\"" << escape_json(event.thumbnail_path) << "\"";
    out << "}";
    return out.str();
}

std::string extract_string(const std::string& json, const std::string& key) {
    const std::regex pattern("\"" + key + "\"\\s*:\\s*\"([^\"]*)\"");
    std::smatch match;
    return std::regex_search(json, match, pattern) ? match[1].str() : "";
}

double extract_number(const std::string& json, const std::string& key) {
    const std::regex pattern("\"" + key + "\"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?)");
    std::smatch match;
    return std::regex_search(json, match, pattern) ? std::stod(match[1].str()) : 0.0;
}

std::vector<std::string> extract_objects(const std::string& json) {
    std::vector<std::string> objects;
    const std::regex array_pattern("\"objects\"\\s*:\\s*\\[([^\\]]*)\\]");
    std::smatch array_match;
    if (!std::regex_search(json, array_match, array_pattern)) {
        return objects;
    }
    const std::string body = array_match[1].str();
    const std::regex item_pattern("\"([^\"]*)\"");
    auto begin = std::sregex_iterator(body.begin(), body.end(), item_pattern);
    auto end = std::sregex_iterator();
    for (auto it = begin; it != end; ++it) {
        objects.push_back((*it)[1].str());
    }
    return objects;
}

Event event_from_json(const std::string& json) {
    Event event;
    event.event_id = extract_string(json, "event_id");
    event.camera_id = extract_string(json, "camera_id");
    event.source = extract_string(json, "source");
    event.action = extract_string(json, "action");
    event.thumbnail_path = extract_string(json, "thumbnail_path");
    event.start_time_s = extract_number(json, "start_time_s");
    event.end_time_s = extract_number(json, "end_time_s");
    event.confidence = extract_number(json, "confidence");
    event.objects = extract_objects(json);
    return event;
}

std::vector<std::string> split_csv(const std::string& value) {
    std::vector<std::string> result;
    std::stringstream stream(value);
    std::string item;
    while (std::getline(stream, item, ',')) {
        item.erase(item.begin(), std::find_if(item.begin(), item.end(), [](unsigned char c) {
            return !std::isspace(c);
        }));
        item.erase(std::find_if(item.rbegin(), item.rend(), [](unsigned char c) {
            return !std::isspace(c);
        }).base(), item.end());
        if (!item.empty()) result.push_back(item);
    }
    return result;
}

std::vector<std::string> tokenize(const std::string& text) {
    std::vector<std::string> tokens;
    std::string current;
    for (char ch : text) {
        if (std::isalnum(static_cast<unsigned char>(ch))) {
            current.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(ch))));
        } else if (!current.empty()) {
            tokens.push_back(current);
            current.clear();
        }
    }
    if (!current.empty()) tokens.push_back(current);
    return tokens;
}

#ifdef RDKC_ENABLE_ONNXRUNTIME
std::string shape_to_string(const std::vector<int64_t>& shape) {
    std::ostringstream out;
    out << "[";
    for (size_t i = 0; i < shape.size(); ++i) {
        if (i) out << ", ";
        if (shape[i] < 0) {
            out << "?";
        } else {
            out << shape[i];
        }
    }
    out << "]";
    return out.str();
}

#ifdef _WIN32
std::wstring widen_path(const std::string& value) {
    return std::wstring(value.begin(), value.end());
}
#endif
#endif

Options parse_options(int argc, char** argv, int start_index) {
    Options options;
    for (int i = start_index; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg.rfind("--", 0) == 0) {
            std::string key = arg.substr(2);
            if (i + 1 < argc && std::string(argv[i + 1]).rfind("--", 0) != 0) {
                options.values[key] = argv[++i];
            } else {
                options.values[key] = "true";
            }
        } else {
            options.positional.push_back(arg);
        }
    }
    return options;
}

Paths paths_from_options(const Options& options) {
    Paths paths;
    if (options.has("data-root")) paths.data_root = options.get("data-root");
    if (options.has("runtime-root")) paths.runtime_root = options.get("runtime-root");
    return paths;
}

void ensure_layout(const Paths& paths) {
    fs::create_directories(paths.data_root / "events");
    fs::create_directories(paths.data_root / "models");
    fs::create_directories(paths.data_root / "faces");
    fs::create_directories(paths.runtime_root / "frames");
    fs::create_directories(paths.runtime_root / "thumbs");
    fs::create_directories(paths.runtime_root / "clips");
}

void write_config_if_missing(const Paths& paths) {
    const fs::path config = paths.data_root / "config.json";
    if (fs::exists(config)) return;
    std::ofstream out(config);
    out << "{\n";
    out << "  \"profile\": \"xb10-cpp-motion-search-mvp\",\n";
    out << "  \"data_root\": \"" << escape_json(paths.data_root.string()) << "\",\n";
    out << "  \"runtime_root\": \"" << escape_json(paths.runtime_root.string()) << "\"\n";
    out << "}\n";
}

std::string read_pgm_token(std::istream& input) {
    std::string token;
    while (input >> token) {
        if (!token.empty() && token[0] == '#') {
            std::string discard;
            std::getline(input, discard);
            continue;
        }
        return token;
    }
    return "";
}

Frame read_pgm(const fs::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("could not open frame: " + path.string());
    }
    const std::string magic = read_pgm_token(input);
    if (magic != "P5" && magic != "P2") {
        throw std::runtime_error("unsupported PGM format: " + path.string());
    }
    Frame frame;
    frame.width = std::stoi(read_pgm_token(input));
    frame.height = std::stoi(read_pgm_token(input));
    const int max_value = std::stoi(read_pgm_token(input));
    if (frame.width <= 0 || frame.height <= 0 || max_value <= 0) {
        throw std::runtime_error("invalid PGM header: " + path.string());
    }
    frame.pixels.resize(static_cast<size_t>(frame.width * frame.height));
    if (magic == "P5") {
        input.get();
        input.read(reinterpret_cast<char*>(frame.pixels.data()), static_cast<std::streamsize>(frame.pixels.size()));
        if (input.gcount() != static_cast<std::streamsize>(frame.pixels.size())) {
            throw std::runtime_error("truncated PGM frame: " + path.string());
        }
    } else {
        for (uint8_t& pixel : frame.pixels) {
            int value = 0;
            input >> value;
            pixel = static_cast<uint8_t>(std::clamp(value * 255 / max_value, 0, 255));
        }
    }
    return frame;
}

double motion_score(const Frame& previous, const Frame& current) {
    if (previous.width != current.width || previous.height != current.height || previous.pixels.size() != current.pixels.size()) {
        return 0.0;
    }
    uint64_t total = 0;
    for (size_t i = 0; i < current.pixels.size(); ++i) {
        total += static_cast<unsigned>(std::abs(static_cast<int>(current.pixels[i]) - static_cast<int>(previous.pixels[i])));
    }
    return static_cast<double>(total) / static_cast<double>(current.pixels.size() * 255.0);
}

std::vector<fs::path> pgm_frames(const fs::path& directory) {
    std::vector<fs::path> frames;
    if (!fs::exists(directory)) return frames;
    for (const auto& entry : fs::directory_iterator(directory)) {
        if (entry.is_regular_file() && entry.path().extension() == ".pgm") {
            frames.push_back(entry.path());
        }
    }
    std::sort(frames.begin(), frames.end());
    return frames;
}

void append_events(const fs::path& index_path, const std::vector<Event>& events) {
    fs::create_directories(index_path.parent_path());
    std::ofstream out(index_path, std::ios::app);
    for (const Event& event : events) {
        out << event_to_json(event) << "\n";
    }
}

std::vector<Event> read_events(const fs::path& index_path) {
    std::vector<Event> events;
    std::ifstream input(index_path);
    std::string line;
    while (std::getline(input, line)) {
        if (!line.empty()) events.push_back(event_from_json(line));
    }
    return events;
}

int command_init(const Options& options) {
    const Paths paths = paths_from_options(options);
    ensure_layout(paths);
    write_config_if_missing(paths);
    std::cout << "Initialized RDKC AI layout\n";
    std::cout << "data_root=" << paths.data_root << "\n";
    std::cout << "runtime_root=" << paths.runtime_root << "\n";
    return 0;
}

int command_health(const Options& options) {
    const Paths paths = paths_from_options(options);
    ensure_layout(paths);
    std::cout << "data_root=" << paths.data_root << "\n";
    std::cout << "runtime_root=" << paths.runtime_root << "\n";
    std::cout << "events_path=" << paths.events_path() << "\n";
#ifdef __linux__
    std::ifstream meminfo("/proc/meminfo");
    std::string line;
    int count = 0;
    while (std::getline(meminfo, line) && count < 8) {
        std::cout << line << "\n";
        ++count;
    }
#else
    std::cout << "meminfo=not_available_on_this_platform\n";
#endif
    return 0;
}

int command_index_frames(const Options& options) {
    Paths paths = paths_from_options(options);
    ensure_layout(paths);

    fs::path frames_path = options.has("frames") ? fs::path(options.get("frames")) : paths.frames_dir();
    fs::path index_path = options.has("index") ? fs::path(options.get("index")) : paths.events_path();
    const std::string camera_id = options.get("camera-id", "front-door");
    const std::string source = options.get("source", frames_path.string());
    const double threshold = std::stod(options.get("threshold", "0.012"));
    const double fps = std::stod(options.get("fps", "1.0"));
    std::vector<std::string> objects = split_csv(options.get("objects", "motion"));
    if (objects.empty()) objects.push_back("motion");
    const std::string action = options.get("event", objects.size() == 1 && objects[0] == "motion" ? "motion" : "object_event");

    const std::vector<fs::path> frames = pgm_frames(frames_path);
    if (frames.size() < 2) {
        std::cerr << "Need at least two .pgm frames in " << frames_path << "\n";
        return 2;
    }

    std::vector<double> scores(frames.size(), 0.0);
    Frame previous = read_pgm(frames[0]);
    for (size_t i = 1; i < frames.size(); ++i) {
        Frame current = read_pgm(frames[i]);
        scores[i] = motion_score(previous, current);
        previous = std::move(current);
    }

    std::vector<Event> events;
    bool active = false;
    size_t start = 0;
    double peak = 0.0;
    const std::string stamp = now_iso_compact();
    int event_number = 1;
    for (size_t i = 1; i < scores.size(); ++i) {
        const bool moving = scores[i] >= threshold;
        if (moving && !active) {
            active = true;
            start = i;
            peak = scores[i];
        } else if (moving && active) {
            peak = std::max(peak, scores[i]);
        } else if (!moving && active) {
            Event event;
            std::ostringstream id;
            id << camera_id << "_" << stamp << "_" << std::setw(4) << std::setfill('0') << event_number++;
            event.event_id = id.str();
            event.camera_id = camera_id;
            event.source = source;
            event.start_time_s = static_cast<double>(start) / fps;
            event.end_time_s = static_cast<double>(i) / fps;
            event.objects = objects;
            event.action = action;
            event.confidence = std::min(1.0, peak / std::max(threshold, 0.0001));
            events.push_back(event);
            active = false;
            peak = 0.0;
        }
    }
    if (active) {
        Event event;
        std::ostringstream id;
        id << camera_id << "_" << stamp << "_" << std::setw(4) << std::setfill('0') << event_number++;
        event.event_id = id.str();
        event.camera_id = camera_id;
        event.source = source;
        event.start_time_s = static_cast<double>(start) / fps;
        event.end_time_s = static_cast<double>(scores.size() - 1) / fps;
        event.objects = objects;
        event.action = action;
        event.confidence = std::min(1.0, peak / std::max(threshold, 0.0001));
        events.push_back(event);
    }

    append_events(index_path, events);
    std::cout << "Indexed " << events.size() << " motion event(s)\n";
    std::cout << "Wrote " << index_path << "\n";
    return 0;
}

int command_search(const Options& options) {
    const Paths paths = paths_from_options(options);
    const fs::path index_path = options.has("index") ? fs::path(options.get("index")) : paths.events_path();
    const std::string query = options.get("query");
    if (query.empty()) {
        std::cerr << "--query is required\n";
        return 2;
    }
    const std::vector<std::string> query_tokens = tokenize(query);
    std::vector<Event> events = read_events(index_path);
    std::vector<std::pair<double, Event>> scored;
    for (const Event& event : events) {
        double score = 0.0;
        for (const std::string& token : query_tokens) {
            if (event.action.find(token) != std::string::npos) score += 0.4;
            for (const std::string& object : event.objects) {
                if (object == token || object.find(token) != std::string::npos) score += 0.6;
            }
        }
        if (score > 0.0) scored.push_back({score + event.confidence * 0.1, event});
    }
    std::sort(scored.begin(), scored.end(), [](const auto& a, const auto& b) {
        return a.first > b.first;
    });
    const size_t limit = static_cast<size_t>(std::stoi(options.get("limit", "10")));
    for (size_t i = 0; i < scored.size() && i < limit; ++i) {
        const Event& event = scored[i].second;
        std::cout << std::fixed << std::setprecision(3) << scored[i].first
                  << " | " << event.event_id
                  << " | " << event.camera_id
                  << " | " << event.start_time_s << "s-" << event.end_time_s << "s"
                  << " | " << event.action
                  << " | " << to_json_array(event.objects)
                  << "\n";
    }
    if (scored.empty()) {
        std::cout << "No matching events found\n";
    }
    return 0;
}

int command_inspect_model(const Options& options) {
    const std::string model_path = options.get("model");
    if (model_path.empty()) {
        std::cerr << "--model is required\n";
        return 2;
    }

#ifndef RDKC_ENABLE_ONNXRUNTIME
    std::cerr << "inspect-model requires an ONNX Runtime enabled build.\n";
    std::cerr << "Rebuild with RDKC_ENABLE_ONNXRUNTIME=1 and ONNXRUNTIME_ROOT=/path/to/onnxruntime.\n";
    return 2;
#else
    const int threads = std::max(1, std::stoi(options.get("threads", "1")));
    Ort::Env env(ORT_LOGGING_LEVEL_WARNING, "rdkc_xb_ai");
    Ort::SessionOptions session_options;
    session_options.SetIntraOpNumThreads(threads);
    session_options.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_BASIC);

#ifdef _WIN32
    const std::wstring wide_model_path = widen_path(model_path);
    Ort::Session session(env, wide_model_path.c_str(), session_options);
#else
    Ort::Session session(env, model_path.c_str(), session_options);
#endif

    Ort::AllocatorWithDefaultOptions allocator;
    const size_t input_count = session.GetInputCount();
    const size_t output_count = session.GetOutputCount();

    std::cout << "Model: " << model_path << "\n";
    std::cout << "Inputs: " << input_count << "\n";
    for (size_t i = 0; i < input_count; ++i) {
        auto name = session.GetInputNameAllocated(i, allocator);
        auto type_info = session.GetInputTypeInfo(i);
        auto tensor_info = type_info.GetTensorTypeAndShapeInfo();
        std::cout << "  " << name.get()
                  << " shape=" << shape_to_string(tensor_info.GetShape())
                  << " element_type=" << static_cast<int>(tensor_info.GetElementType())
                  << "\n";
    }

    std::cout << "Outputs: " << output_count << "\n";
    for (size_t i = 0; i < output_count; ++i) {
        auto name = session.GetOutputNameAllocated(i, allocator);
        auto type_info = session.GetOutputTypeInfo(i);
        auto tensor_info = type_info.GetTensorTypeAndShapeInfo();
        std::cout << "  " << name.get()
                  << " shape=" << shape_to_string(tensor_info.GetShape())
                  << " element_type=" << static_cast<int>(tensor_info.GetElementType())
                  << "\n";
    }
    return 0;
#endif
}

void usage() {
    std::cout << "rdkc_xb_ai <command> [options]\n\n";
    std::cout << "Commands:\n";
    std::cout << "  init          Create /data and /tmp RDKC AI folders\n";
    std::cout << "  health        Print basic runtime readiness\n";
    std::cout << "  index-frames  Index motion events from .pgm frames\n";
    std::cout << "  inspect-model Print ONNX model input/output names and shapes\n";
    std::cout << "  search        Search the JSONL event index\n\n";
    std::cout << "Common options:\n";
    std::cout << "  --data-root /data/rdkc_ai\n";
    std::cout << "  --runtime-root /tmp/rdkc_ai\n";
}

}  // namespace

int main(int argc, char** argv) {
    if (argc < 2 || std::string(argv[1]) == "--help" || std::string(argv[1]) == "-h") {
        usage();
        return argc < 2 ? 2 : 0;
    }

    const std::string command = argv[1];
    const Options options = parse_options(argc, argv, 2);
    try {
        if (command == "init") return command_init(options);
        if (command == "health") return command_health(options);
        if (command == "index-frames") return command_index_frames(options);
        if (command == "inspect-model") return command_inspect_model(options);
        if (command == "search") return command_search(options);
    } catch (const std::exception& exc) {
        std::cerr << "error: " << exc.what() << "\n";
        return 1;
    }

    std::cerr << "unknown command: " << command << "\n";
    usage();
    return 2;
}
