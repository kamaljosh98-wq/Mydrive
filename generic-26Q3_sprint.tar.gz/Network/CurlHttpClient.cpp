#include "CurlHttpClient.hpp"
//#include "Logger.hpp"
#include <iostream>
#include <fstream>
#include <chrono>
#include <thread>
#include <iomanip>
#include <vector>

// TODO: we should remove the below code and include Logger.hpp, once we integrate xvision with log4cplus 
#define LOG_INFO(...) std::cout << "[INFO] " << __VA_ARGS__ << std::endl
#define LOG_DEBUG(...) std::cout << "[DEBUG] " << __VA_ARGS__ << std::endl
#define LOG_ERROR(...) std::cerr << "[ERROR] " << __VA_ARGS__ << std::endl

constexpr char CA_CERT_FILE[] = "/etc/ssl/certs/CAcerts.pem";

CurlHttpClient::CurlHttpClient() : curl(curl_easy_init()), headers(nullptr), mCACertFileName(CA_CERT_FILE), responseCode(0)
{
    curl_global_init(CURL_GLOBAL_DEFAULT);
}

CurlHttpClient::~CurlHttpClient()
{
    if (curl)
    {
        curl_easy_cleanup(curl);
    }
    curl_slist_free_all(headers);
    curl_global_cleanup();
}

size_t CurlHttpClient::readCallback(void *ptr, size_t size, size_t nmemb, void *stream)
{
    std::ifstream *file = static_cast<std::ifstream *>(stream);
    if (file->eof() || file->fail())
    {
        return 0;
    }
    file->read(static_cast<char *>(ptr), size * nmemb);
    return file->gcount();
}

void CurlHttpClient::appendHeader(const std::string &headerName, const std::string &headerValue)
{
    std::string header = headerName + ": " + headerValue;
    headers = curl_slist_append(headers, header.c_str());
}

void CurlHttpClient::resetHeaders()
{
    if (headers)
    {
        curl_slist_free_all(headers);
        headers = nullptr;
    }
}

long CurlHttpClient::getResponseCode() const
{
    return responseCode;
}

std::string CurlHttpClient::getResponseData() const
{
    return responseData;
}

size_t CurlHttpClient::writeCallback(void *ptr, size_t size, size_t nmemb, void *userdata)
{
    // Implement your write callback if needed
    std::string *response = static_cast<std::string *>(userdata);
    response->append(static_cast<char *>(ptr), size * nmemb);
    return size * nmemb;
}

int CurlHttpClient::progressCallback(void *clientp, curl_off_t dltotal, curl_off_t dlnow, curl_off_t ultotal, curl_off_t ulnow)
{
    // Implement your progress callback if needed
    return 0; // Return 0 to continue, non-zero to abort
}
void CurlHttpClient::applyCurlOptions()
{
    if (!curl)
    {
        LOG_ERROR("CURL not initialized.");
        return;
    }

    // Set options that are common to both connect() and downloadData()
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);             // Set headers
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);              // Follow redirects
    curl_easy_setopt(curl, CURLOPT_CAINFO, mCACertFileName.c_str()); // Use CA certificate file
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);             // Timeout for connection
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);    // Callback to capture response data
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);        // Where to store the response data
}
bool CurlHttpClient::uploadFile(const std::string &url, const std::string &filePath)
{
    LOG_DEBUG("Called uploadFile");

    if (!curl)
    {
        LOG_INFO("Failed to initialize curl");
        return false;
    }
    curl_easy_reset(curl);

    std::ifstream file(filePath, std::ios::binary);
    if (!file.is_open())
    {
        LOG_INFO("Failed to open file: " << filePath);
        return false;
    }
    std::vector<char> fileContent((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();

    appendHeader("Content-Length", std::to_string(fileContent.size()));

    struct curl_slist *local_headers = headers;
    curl_easy_setopt(curl, CURLOPT_VERBOSE, 0L);
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, fileContent.data());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, fileContent.size());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, progressCallback);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_CAINFO, mCACertFileName.c_str());
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15);   // Time to establish connection
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_LIMIT, 10L); // Minimum transfer speed in bytes per second
    curl_easy_setopt(curl, CURLOPT_LOW_SPEED_TIME, 10L);  // Time in seconds the transfer speed must be below the limit before aborting

    auto overallStart = std::chrono::steady_clock::now();
    int retries = 3;
    bool success = false;

    while (retries-- > 0)
    {
        LOG_DEBUG("Attempt: " << 3 - retries);
        auto retryStart = std::chrono::steady_clock::now();
        res = curl_easy_perform(curl);
        auto end = std::chrono::steady_clock::now();
        auto retryEnd = std::chrono::steady_clock::now();
        std::chrono::duration<double> retryDuration = retryEnd - retryStart;

        if (res == CURLE_OK)
        {
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &responseCode);
            if (responseCode >= 200 && responseCode < 399)
            {
                success = true;
                break;
            }
            else
            {
                LOG_INFO("Server responded with code: " << responseCode);
            }
        }
        else
        {
            LOG_INFO("curl_easy_perform() failed: " << curl_easy_strerror(res));
        }

        auto overallElapsed = std::chrono::steady_clock::now() - overallStart;
        if (retries > 0 && overallElapsed.count() + retryDuration.count() < 15)
        {
            std::this_thread::sleep_for(std::chrono::seconds(15) - overallElapsed);
        }
        else
        {
            break; // Exit the loop if the overall time exceeds 15 seconds
        }
    }

    // Delete the file after upload attempt
    if (std::remove(filePath.c_str()) != 0)
    {
        LOG_ERROR("Error deleting file: " << filePath);
    }

    // Free headers if they were dynamically allocated
    if (local_headers != headers)
    {
        curl_slist_free_all(local_headers);
    }

    return success;
}
bool CurlHttpClient::connect(const std::string &url)
{
    LOG_DEBUG("Connecting to start stream at: " << url);

    if (!curl)
    {
        LOG_ERROR("Failed to initialize curl");
        return false;
    }

    // Clear any previous headers and response data, but do not reset CURL to reuse the connection
    responseData.clear();

    // Set the URL for starting the stream (e.g., /start_stream/1)
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

    // Apply common curl options
    applyCurlOptions();

    // Perform the connection request
    CURLcode res = curl_easy_perform(curl);

    // Check for errors
    if (res != CURLE_OK)
    {
        LOG_ERROR("curl_easy_perform() failed: " << curl_easy_strerror(res));
        return false;
    }

    // Get the response code
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &responseCode);

    // Check for successful response
    if (responseCode >= 200 && responseCode < 300)
    {
        LOG_INFO("Stream started successfully with response code: " << responseCode);
        return true;
    }
    else
    {
        LOG_ERROR("Failed to start stream. Server responded with code: " << responseCode);
        return false;
    }
}
// Download frame data using the same connection (without resetting CURL)
bool CurlHttpClient::downloadData(const std::string &url)
{
    LOG_DEBUG("Downloading frame data from: " << url);

    if (!curl)
    {
        LOG_ERROR("Failed to initialize curl");
        return false;
    }

    // Clear previous response data but do not reset the CURL handle
    responseData.clear();

    // Set the URL to fetch the next frame (e.g., /request_frame/1)
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

    // Perform the request to download the frame using the existing connection
    CURLcode res = curl_easy_perform(curl);

    // Check for errors
    if (res != CURLE_OK)
    {
        LOG_ERROR("curl_easy_perform() failed: " << curl_easy_strerror(res));
        return false;
    }

    // Get the response code
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &responseCode);

    // Check for successful response
    if (responseCode >= 200 && responseCode < 300)
    {
        LOG_INFO("Frame downloaded successfully with response code: " << responseCode);
        return true;
    }
    else
    {
        LOG_ERROR("Failed to download frame. Server responded with code: " << responseCode);
        return false;
    }
}

