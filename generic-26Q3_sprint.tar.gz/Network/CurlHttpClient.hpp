#ifndef CURL_HTTP_CLIENT_HPP
#define CURL_HTTP_CLIENT_HPP

#include <string>
#include <curl/curl.h>

class CurlHttpClient
{
public:
    // Constructor to initialize the CurlHttpClient object	
    CurlHttpClient();

    // Destructor to clean up resources
    ~CurlHttpClient();

    // Establish a connection to the specified URL
    bool connect(const std::string &url);

    // Upload a file to the specified URL
    bool uploadFile(const std::string &url, const std::string &filePath);

    // Download data from the specified URL
    bool downloadData(const std::string &url);

    // Add a custom header to the request
    void appendHeader(const std::string &headerName, const std::string &headerValue);

    // Reset the custom headers for the next request
    void resetHeaders();

    // Get the HTTP response code from the last request
    long getResponseCode() const;

    // Get the response data from the last request
    std::string getResponseData() const;

private:
    // CURL handle for making requests
    CURL *curl;

    // Stores the result of the last CURL operation
    CURLcode res;

    // Linked list of custom headers
    struct curl_slist *headers;

    // Path to the CA certificate file
    std::string mCACertFileName;

    // HTTP response code from the last request
    long responseCode;

    // Data returned from the server in the last request
    std::string responseData;

    // Callback function for reading data during upload
    static size_t readCallback(void *ptr, size_t size, size_t nmemb, void *stream);

    // Callback function for writing data during download
    static size_t writeCallback(void *ptr, size_t size, size_t nmemb, void *userdata);

    // Callback function for progress reporting
    static int progressCallback(void *clientp, curl_off_t dltotal, curl_off_t dlnow, curl_off_t ultotal, curl_off_t ulnow);

    // Apply common CURL options for the request
    void applyCurlOptions();
};

#endif // CURL_HTTP_CLIENT_HPP

