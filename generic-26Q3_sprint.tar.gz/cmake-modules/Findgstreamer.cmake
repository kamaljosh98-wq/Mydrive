##########################################################################
# Findgstreamer.cmake
# 
# Creates individual imported targets for GStreamer libraries:
#   gstreamer::gstreamer-1.0, gstreamer::gstapp-1.0
#
# Also provides gstreamer::gstreamer aggregated target for backward compatibility.
##########################################################################

if (NOT GSTREAMER_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_GSTREAMER QUIET gstreamer-1.0 gstreamer-app-1.0)

find_path(GSTREAMER_INCLUDE_DIRS NAMES gst/gst.h PATHS ${PC_GSTREAMER_INCLUDE_DIRS})
find_library(GSTREAMER_LIB NAMES gstreamer-1.0 PATHS ${PC_GSTREAMER_LIBRARY_DIRS})
find_library(GSTAPP_LIB NAMES gstapp-1.0 PATHS ${PC_GSTREAMER_LIBRARY_DIRS})

# Build library list
set(GSTREAMER_LIBRARIES)
if(GSTREAMER_LIB)
    list(APPEND GSTREAMER_LIBRARIES ${GSTREAMER_LIB})
endif()
if(GSTAPP_LIB)
    list(APPEND GSTREAMER_LIBRARIES ${GSTAPP_LIB})
endif()

# Set deprecated variables
set(GSTREAMER_LIBRARY "${GSTREAMER_LIB}")
set(GSTREAMER_INCLUDE_DIR "${GSTREAMER_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(gstreamer DEFAULT_MSG GSTREAMER_LIBRARIES)

# Create individual imported targets per library (not aggregated)
if (GSTREAMER_FOUND)
    # gstreamer::gstreamer-1.0 (core GStreamer library)
    if(GSTREAMER_LIB AND NOT TARGET gstreamer::gstreamer-1.0)
        add_library(gstreamer::gstreamer-1.0 UNKNOWN IMPORTED)
        set_target_properties(gstreamer::gstreamer-1.0 PROPERTIES
            IMPORTED_LOCATION "${GSTREAMER_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_GSTREAMER_CFLAGS_OTHER}")
        if(GSTREAMER_INCLUDE_DIRS)
            set_property(TARGET gstreamer::gstreamer-1.0 PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${GSTREAMER_INCLUDE_DIRS}")
        endif()
    endif()
    
    # gstreamer::gstapp-1.0 (application integration library, depends on core)
    if(GSTAPP_LIB AND NOT TARGET gstreamer::gstapp-1.0)
        add_library(gstreamer::gstapp-1.0 UNKNOWN IMPORTED)
        set_target_properties(gstreamer::gstapp-1.0 PROPERTIES
            IMPORTED_LOCATION "${GSTAPP_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_GSTREAMER_CFLAGS_OTHER}")
        if(GSTREAMER_INCLUDE_DIRS)
            set_property(TARGET gstreamer::gstapp-1.0 PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${GSTREAMER_INCLUDE_DIRS}")
        endif()
        # gstapp depends on gstreamer core
        if(TARGET gstreamer::gstreamer-1.0)
            set_property(TARGET gstreamer::gstapp-1.0 APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES gstreamer::gstreamer-1.0)
        endif()
    endif()
    
    # Legacy aggregated target for backward compatibility
    if(NOT TARGET gstreamer::gstreamer)
        add_library(gstreamer::gstreamer INTERFACE IMPORTED)
        set_property(TARGET gstreamer::gstreamer PROPERTY
            INTERFACE_LINK_LIBRARIES gstreamer::gstreamer-1.0 gstreamer::gstapp-1.0)
    endif()
endif()

mark_as_advanced(GSTREAMER_INCLUDE_DIR GSTREAMER_LIBRARY
                 GSTREAMER_INCLUDE_DIRS GSTREAMER_LIBRARIES
                 GSTREAMER_LIB GSTAPP_LIB)

endif()
