##########################################################################
# Findmiscutils.cmake
#
# Find miscellaneous utility library (fileUtils, etc.).
# Creates imported target: miscutils::miscutils
##########################################################################

if (NOT MISCUTILS_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_MISCUTILS QUIET miscutils)

find_path(MISCUTILS_INCLUDE_DIRS NAMES fileUtils.h PATHS ${PC_MISCUTILS_INCLUDE_DIRS})
find_library(MISCUTILS_LIBRARIES NAMES miscutils PATHS ${PC_MISCUTILS_LIBRARY_DIRS})

# Set deprecated variables
set(MISCUTILS_LIBRARY "${MISCUTILS_LIBRARIES}")
set(MISCUTILS_INCLUDE_DIR "${MISCUTILS_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(miscutils DEFAULT_MSG MISCUTILS_LIBRARIES MISCUTILS_INCLUDE_DIRS)

if (MISCUTILS_FOUND AND NOT TARGET miscutils::miscutils)
    add_library(miscutils::miscutils UNKNOWN IMPORTED)
    set_target_properties(miscutils::miscutils PROPERTIES
                          IMPORTED_LOCATION "${MISCUTILS_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_MISCUTILS_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${MISCUTILS_INCLUDE_DIRS}")
endif()

mark_as_advanced(MISCUTILS_INCLUDE_DIR MISCUTILS_LIBRARY
                 MISCUTILS_INCLUDE_DIRS MISCUTILS_LIBRARIES)

endif()
