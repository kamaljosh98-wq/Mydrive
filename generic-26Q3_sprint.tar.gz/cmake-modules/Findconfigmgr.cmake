##########################################################################
# Findconfigmgr.cmake
# 
# Creates individual imported targets for configmgr libraries:
#   configmgr::rfcconfig, configmgr::configmanager
#
# Link order: rfcconfig → configmanager
# Note: mxml has its own separate find module (Findmxml.cmake)
##########################################################################

if (NOT CONFIGMGR_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_CONFIGMGR QUIET configmgr)

find_path(CONFIGMGR_INCLUDE_DIRS NAMES config_api.h PATHS ${PC_CONFIGMGR_INCLUDE_DIRS})
find_library(CONFIGMGR_RFCCONFIG_LIB NAMES rfcconfig PATHS ${PC_CONFIGMGR_LIBRARY_DIRS})
find_library(CONFIGMGR_CONFIGMANAGER_LIB NAMES configmanager PATHS ${PC_CONFIGMGR_LIBRARY_DIRS})

# Build library list in link order (only libraries actually used)
set(CONFIGMGR_LIBRARIES)
if(CONFIGMGR_RFCCONFIG_LIB)
    list(APPEND CONFIGMGR_LIBRARIES ${CONFIGMGR_RFCCONFIG_LIB})
endif()
if(CONFIGMGR_CONFIGMANAGER_LIB)
    list(APPEND CONFIGMGR_LIBRARIES ${CONFIGMGR_CONFIGMANAGER_LIB})
endif()

# Set deprecated variables
set(CONFIGMGR_LIBRARY "${CONFIGMGR_CONFIGMANAGER_LIB}")
set(CONFIGMGR_INCLUDE_DIR "${CONFIGMGR_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(configmgr DEFAULT_MSG CONFIGMGR_CONFIGMANAGER_LIB CONFIGMGR_INCLUDE_DIRS)

if (CONFIGMGR_FOUND)
    # configmgr::rfcconfig
    if(CONFIGMGR_RFCCONFIG_LIB AND NOT TARGET configmgr::rfcconfig)
        add_library(configmgr::rfcconfig UNKNOWN IMPORTED)
        set_target_properties(configmgr::rfcconfig PROPERTIES
            IMPORTED_LOCATION "${CONFIGMGR_RFCCONFIG_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_CONFIGMGR_CFLAGS_OTHER}"
            INTERFACE_INCLUDE_DIRECTORIES "${CONFIGMGR_INCLUDE_DIRS}")
    endif()

    # configmgr::configmanager (depends on mxml)
    if(CONFIGMGR_CONFIGMANAGER_LIB AND NOT TARGET configmgr::configmanager)
        add_library(configmgr::configmanager UNKNOWN IMPORTED)
        set_target_properties(configmgr::configmanager PROPERTIES
            IMPORTED_LOCATION "${CONFIGMGR_CONFIGMANAGER_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_CONFIGMGR_CFLAGS_OTHER}"
            INTERFACE_INCLUDE_DIRECTORIES "${CONFIGMGR_INCLUDE_DIRS}")
        # configmanager depends on mxml
        find_package(mxml QUIET)
        if(TARGET mxml::mxml)
            set_property(TARGET configmgr::configmanager APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES mxml::mxml)
        endif()
    endif()
endif()

mark_as_advanced(CONFIGMGR_INCLUDE_DIR CONFIGMGR_LIBRARY
                 CONFIGMGR_INCLUDE_DIRS CONFIGMGR_LIBRARIES
                 CONFIGMGR_RFCCONFIG_LIB CONFIGMGR_CONFIGMANAGER_LIB)

endif()
