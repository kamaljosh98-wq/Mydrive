##########################################################################
# Findmsgpackc.cmake
#
# Find MessagePack C library for serialization.
# Creates imported target: msgpackc::msgpackc
##########################################################################

if (NOT MSGPACKC_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_MSGPACKC QUIET msgpack)

find_path(MSGPACKC_INCLUDE_DIRS NAMES msgpack.h PATHS ${PC_MSGPACKC_INCLUDE_DIRS})
find_library(MSGPACKC_LIBRARIES NAMES msgpackc PATHS ${PC_MSGPACKC_LIBRARY_DIRS})

# Set deprecated variables
set(MSGPACKC_LIBRARY "${MSGPACKC_LIBRARIES}")
set(MSGPACKC_INCLUDE_DIR "${MSGPACKC_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(msgpackc DEFAULT_MSG MSGPACKC_LIBRARIES MSGPACKC_INCLUDE_DIRS)

if (MSGPACKC_FOUND AND NOT TARGET msgpackc::msgpackc)
    add_library(msgpackc::msgpackc UNKNOWN IMPORTED)
    set_target_properties(msgpackc::msgpackc PROPERTIES
                          IMPORTED_LOCATION "${MSGPACKC_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_MSGPACKC_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${MSGPACKC_INCLUDE_DIRS}")
endif()

mark_as_advanced(MSGPACKC_INCLUDE_DIR MSGPACKC_LIBRARY
                 MSGPACKC_INCLUDE_DIRS MSGPACKC_LIBRARIES)

endif()
