##########################################################################
# Findbreakpad.cmake
#
# Find Google Breakpad crash reporting library.
# Creates imported target: breakpad::breakpad
##########################################################################

if (NOT BREAKPAD_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_BREAKPAD QUIET breakpad)

find_path(BREAKPAD_INCLUDE_DIRS NAMES breakpadwrap.h PATHS ${PC_BREAKPAD_INCLUDE_DIRS})
find_library(BREAKPAD_LIBRARIES NAMES breakpadwrap PATHS ${PC_BREAKPAD_LIBRARY_DIRS})

# Set deprecated variables
set(BREAKPAD_LIBRARY "${BREAKPAD_LIBRARIES}")
set(BREAKPAD_INCLUDE_DIR "${BREAKPAD_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(breakpad DEFAULT_MSG BREAKPAD_LIBRARIES BREAKPAD_INCLUDE_DIRS)

if (BREAKPAD_FOUND AND NOT TARGET breakpad::breakpad)
    add_library(breakpad::breakpad UNKNOWN IMPORTED)
    set_target_properties(breakpad::breakpad PROPERTIES
                          IMPORTED_LOCATION "${BREAKPAD_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_BREAKPAD_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${BREAKPAD_INCLUDE_DIRS}"
                          INTERFACE_COMPILE_DEFINITIONS "BREAKPAD")
    # Also link breakpad_client library
    find_library(BREAKPAD_CLIENT_LIB NAMES breakpad_client PATHS ${PC_BREAKPAD_LIBRARY_DIRS})
    if(BREAKPAD_CLIENT_LIB)
        set_property(TARGET breakpad::breakpad APPEND PROPERTY INTERFACE_LINK_LIBRARIES "${BREAKPAD_CLIENT_LIB}")
    endif()
endif()

mark_as_advanced(BREAKPAD_INCLUDE_DIR BREAKPAD_LIBRARY
                 BREAKPAD_INCLUDE_DIRS BREAKPAD_LIBRARIES)

endif()
