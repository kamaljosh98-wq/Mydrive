##########################################################################
# Findzlib.cmake
#
# Find zlib compression library.
# Creates imported target: zlib::zlib
##########################################################################

if (NOT ZLIB_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_ZLIB QUIET zlib)

find_path(ZLIB_INCLUDE_DIRS NAMES zlib.h PATHS ${PC_ZLIB_INCLUDE_DIRS})
find_library(ZLIB_LIBRARIES NAMES z PATHS ${PC_ZLIB_LIBRARY_DIRS})

# Set deprecated variables
set(ZLIB_LIBRARY "${ZLIB_LIBRARIES}")
set(ZLIB_INCLUDE_DIR "${ZLIB_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(zlib DEFAULT_MSG ZLIB_LIBRARIES ZLIB_INCLUDE_DIRS)

if (ZLIB_FOUND AND NOT TARGET zlib::zlib)
    add_library(zlib::zlib UNKNOWN IMPORTED)
    set_target_properties(zlib::zlib PROPERTIES
                          IMPORTED_LOCATION "${ZLIB_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_ZLIB_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${ZLIB_INCLUDE_DIRS}")
endif()

mark_as_advanced(ZLIB_INCLUDE_DIR ZLIB_LIBRARY
                 ZLIB_INCLUDE_DIRS ZLIB_LIBRARIES)

endif()
