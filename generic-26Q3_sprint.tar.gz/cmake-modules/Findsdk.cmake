if (NOT SDK_FOUND)
    if(DEFINED STAGING_DIR_TARGET OR DEFINED RDK_FSROOT_PATH)
        include(RDKPaths)
    endif()
    find_package(PkgConfig)
    if (PKG_CONFIG_FOUND)
        pkg_check_modules(SDK_PC QUIET sdk)
    endif()

    # Ensure we pick up the toolchain path from the environment if CMake
    # variables were not set by other scripts. This is important for CI
    # environments that export RDK_TOOLCHAIN_PATH but don't set it as a
    # CMake variable.
    if(NOT DEFINED RDK_TOOLCHAIN_PATH AND DEFINED ENV{RDK_TOOLCHAIN_PATH})
        set(RDK_TOOLCHAIN_PATH "$ENV{RDK_TOOLCHAIN_PATH}")
    endif()

    # Derive a reasonable TOOLCHAIN_LIB_PATH from the toolchain root if
    # a dedicated variable wasn't already provided by RDKPaths.
    if(NOT DEFINED TOOLCHAIN_LIB_PATH AND DEFINED RDK_TOOLCHAIN_PATH)
        set(_tc_try_1 "${RDK_TOOLCHAIN_PATH}/linaro-armv7ahf-2015.11-gcc5.2/arm-linux-gnueabihf/libc/usr/lib")
        set(_tc_try_2 "${RDK_TOOLCHAIN_PATH}/arm-linux-gnueabihf/libc/usr/lib")
        set(_tc_try_3 "${RDK_TOOLCHAIN_PATH}/lib")
        if(EXISTS "${_tc_try_1}")
            set(TOOLCHAIN_LIB_PATH "${_tc_try_1}" CACHE PATH "" FORCE)
        elseif(EXISTS "${_tc_try_2}")
            set(TOOLCHAIN_LIB_PATH "${_tc_try_2}" CACHE PATH "" FORCE)
        elseif(EXISTS "${_tc_try_3}")
            set(TOOLCHAIN_LIB_PATH "${_tc_try_3}" CACHE PATH "" FORCE)
        endif()
    endif()

    # For system libraries (m, dl, pthread, rt, resolv), search in standard paths
    # In Yocto builds, CMAKE_FIND_ROOT_PATH should be set by toolchain
    # In non-Yocto builds, also search in TOOLCHAIN_LIB_PATH or derived paths
    set(SYSTEM_LIB_SEARCH_PATHS "")
    if(PC_SDK_LIBRARY_DIRS)
        list(APPEND SYSTEM_LIB_SEARCH_PATHS ${PC_SDK_LIBRARY_DIRS})
    endif()
    if(DEFINED TOOLCHAIN_LIB_PATH)
        list(APPEND SYSTEM_LIB_SEARCH_PATHS ${TOOLCHAIN_LIB_PATH})
    endif()
    # In Yocto, also search in the sysroot paths
    if(DEFINED LIB_PATH)
        list(APPEND SYSTEM_LIB_SEARCH_PATHS ${LIB_PATH})
    endif()
    # For non-Yocto cross-compile, derive standard lib paths from toolchain
    if(DEFINED RDK_TOOLCHAIN_PATH AND NOT DEFINED TOOLCHAIN_LIB_PATH)
        # Try common cross-compile libc paths
        list(APPEND SYSTEM_LIB_SEARCH_PATHS 
            "${RDK_TOOLCHAIN_PATH}/arm-linux-gnueabihf/libc/lib"
            "${RDK_TOOLCHAIN_PATH}/arm-linux-gnueabihf/libc/usr/lib"
            "${RDK_TOOLCHAIN_PATH}/arm-linux-gnueabihf/lib"
            "${RDK_TOOLCHAIN_PATH}/arm-linux-gnueabihf/usr/lib"
        )
    endif()

    # Debug: Log the system library search paths
    message(STATUS "Findsdk: SYSTEM_LIB_SEARCH_PATHS = ${SYSTEM_LIB_SEARCH_PATHS}")
    message(STATUS "Findsdk: RDK_TOOLCHAIN_PATH = ${RDK_TOOLCHAIN_PATH}")

    find_library(Z_LIB NAMES z HINTS ${PC_SDK_LIBRARY_DIRS} PATHS ${LIB_PATH} ${SHADOW_ROOT_LIB_PATH})
    if (Z_LIB AND NOT TARGET sdk::z)
        add_library(sdk::z UNKNOWN IMPORTED)
        set_target_properties(sdk::z PROPERTIES
            IMPORTED_LOCATION "${Z_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(Z_LIB)
    endif()

    find_library(M_LIB NAMES m HINTS ${SYSTEM_LIB_SEARCH_PATHS})
    # If not found via pkg-config paths, try standard paths without hints
    if(NOT M_LIB)
        find_library(M_LIB NAMES m)
    endif()
    if (M_LIB AND NOT TARGET sdk::m)
        add_library(sdk::m UNKNOWN IMPORTED)
        set_target_properties(sdk::m PROPERTIES
            IMPORTED_LOCATION "${M_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(M_LIB)
    endif()

    find_library(DL_LIB NAMES dl HINTS ${SYSTEM_LIB_SEARCH_PATHS})
    # If not found via pkg-config paths, try standard paths without hints
    if(NOT DL_LIB)
        find_library(DL_LIB NAMES dl)
    endif()
    if (DL_LIB AND NOT TARGET sdk::dl)
        add_library(sdk::dl UNKNOWN IMPORTED)
        set_target_properties(sdk::dl PROPERTIES
            IMPORTED_LOCATION "${DL_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(DL_LIB)
    endif()

    find_library(DEWARP_LIB NAMES dewarp HINTS ${PC_SDK_LIBRARY_DIRS} PATHS ${LIB_PATH} ${SHADOW_ROOT_LIB_PATH})
    if (DEWARP_LIB AND NOT TARGET sdk::dewarp)
        add_library(sdk::dewarp UNKNOWN IMPORTED)
        set_target_properties(sdk::dewarp PROPERTIES
            IMPORTED_LOCATION "${DEWARP_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(DEWARP_LIB)
    endif()

    find_library(CRYPTO_LIB NAMES crypto HINTS ${PC_SDK_LIBRARY_DIRS} PATHS ${LIB_PATH} ${SHADOW_ROOT_LIB_PATH})
    if (CRYPTO_LIB AND NOT TARGET sdk::crypto)
        add_library(sdk::crypto UNKNOWN IMPORTED)
        set_target_properties(sdk::crypto PROPERTIES
            IMPORTED_LOCATION "${CRYPTO_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(CRYPTO_LIB)
    endif()

    find_library(MXML_LIB NAMES mxml HINTS ${PC_SDK_LIBRARY_DIRS} PATHS ${LIB_PATH} ${SHADOW_ROOT_LIB_PATH})
    if (MXML_LIB AND NOT TARGET sdk::mxml)
        add_library(sdk::mxml UNKNOWN IMPORTED)
        set_target_properties(sdk::mxml PROPERTIES
            IMPORTED_LOCATION "${MXML_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(MXML_LIB)
    endif()

    find_library(PTHREAD_LIB NAMES pthread HINTS ${SYSTEM_LIB_SEARCH_PATHS})
    # If not found via pkg-config paths, try standard paths without hints
    if(NOT PTHREAD_LIB)
        find_library(PTHREAD_LIB NAMES pthread)
    endif()
    if (PTHREAD_LIB AND NOT TARGET sdk::pthread)
        add_library(sdk::pthread UNKNOWN IMPORTED)
        set_target_properties(sdk::pthread PROPERTIES
            IMPORTED_LOCATION "${PTHREAD_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(PTHREAD_LIB)
    endif()

    find_library(SCCOMM_LIB NAMES sccomm HINTS ${PC_SDK_LIBRARY_DIRS} PATHS ${SCCOMM_LIB_DIR} ${LIB_PATH} ${SHADOW_ROOT_LIB_PATH})
    if (SCCOMM_LIB AND NOT TARGET sdk::sccomm)
        add_library(sdk::sccomm UNKNOWN IMPORTED)
        set_target_properties(sdk::sccomm PROPERTIES
            IMPORTED_LOCATION "${SCCOMM_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(SCCOMM_LIB)
    endif()

    find_library(RT_LIB NAMES rt HINTS ${SYSTEM_LIB_SEARCH_PATHS})
    # If not found via pkg-config paths, try standard paths without hints
    if(NOT RT_LIB)
        find_library(RT_LIB NAMES rt)
    endif()
    if (RT_LIB AND NOT TARGET sdk::rt)
        add_library(sdk::rt UNKNOWN IMPORTED)
        set_target_properties(sdk::rt PROPERTIES
            IMPORTED_LOCATION "${RT_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(RT_LIB)
    endif()

    find_library(RESOLV_LIB NAMES resolv HINTS ${SYSTEM_LIB_SEARCH_PATHS})
    # If not found via pkg-config paths, try standard paths without hints
    if(NOT RESOLV_LIB)
        find_library(RESOLV_LIB NAMES resolv)
    endif()
    if (RESOLV_LIB AND NOT TARGET sdk::resolv)
        add_library(sdk::resolv UNKNOWN IMPORTED)
        set_target_properties(sdk::resolv PROPERTIES
            IMPORTED_LOCATION "${RESOLV_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${SDK_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_SDK_CFLAGS_OTHER}"
        )
        mark_as_advanced(RESOLV_LIB)
    endif()

    if (NOT TARGET sdk::sdk)
        add_library(sdk::sdk INTERFACE IMPORTED)
        set_target_properties(sdk::sdk PROPERTIES
            INTERFACE_LINK_LIBRARIES "sdk::z;sdk::m;sdk::dl;sdk::dewarp;sdk::crypto;sdk::mxml;sdk::pthread;sdk::sccomm;sdk::rt;sdk::resolv"
        )
    endif()

    include(FindPackageHandleStandardArgs)
    find_package_handle_standard_args(sdk DEFAULT_MSG Z_LIB M_LIB DL_LIB DEWARP_LIB CRYPTO_LIB MXML_LIB PTHREAD_LIB SCCOMM_LIB RT_LIB RESOLV_LIB)

endif()
