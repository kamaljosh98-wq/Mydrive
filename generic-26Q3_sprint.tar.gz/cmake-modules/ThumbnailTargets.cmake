##########################################################################
# ThumbnailTargets.cmake
#
# Unified target creation helper for thumbnail camera daemons.
# Provides create_thumbnail_daemon() function that abstracts all
# dependency detection, include paths, linking, and installation.
#
# PUBLIC API:
#   - create_thumbnail_daemon()  - Main function to create thumbnail targets
#
# PARAMETERS:
#   - TARGET: Target name (required)
#   - PREFIX: Feature option prefix for global cache
#   - SOURCES: Source files (required)
#   - FEATURES: Feature triplets (NAME "Description" DEFAULT)
#   - EXTRA_SOURCES, EXTRA_INCLUDES, EXTRA_DEFINES, EXTRA_LIBRARIES
#   - VERBOSE_SUMMARY: Print detailed configuration
#   - INSTALL: Enable installation rules
#
# FEATURES SUPPORTED:
#   - USE_HTTPCLIENT, USE_CONFIGMGR, USE_RBUS, USE_MFRLIB, USE_SYSUTILS
#   - USE_LIBSYSWRAPPER, USE_BREAKPAD, USE_FILEUTILS, USE_TELEMETRY_2
#   - USE_FFMPEG, USE_OPENCV, USE_GSTREAMER, USE_BASE64, SUPPORT_MXML
#
# AUTOMATIC HANDLING:
#   - Feature-based find_package() calls
#   - Include directory detection from source files
#   - Consumer/Plugin XStreamer includes
#   - OpenCV library filtering (only existing libs)
#   - ConfigMgr MXML dependency fix
#   - Common dependencies (Threads, RDKLogger, RTMessage)
##########################################################################

# Include guard for CMake 3.8 compatibility
if(THUMBNAIL_TARGETS_INCLUDED)
    return()
endif()
set(THUMBNAIL_TARGETS_INCLUDED TRUE)

# Include common helpers
include(ThumbnailCommon)

##########################################################################
# create_thumbnail_daemon
#
# Unified function to create a thumbnail daemon target with automatic
# dependency detection, include path management, and feature-based linking.
#
# Usage:
#   create_thumbnail_daemon(
#       TARGET target_name
#       PREFIX feature_prefix
#       SOURCES source1.cpp source2.cpp ...
#       FEATURES
#           FEATURE_NAME "Description" <ON|OFF>
#           ...
#       [EXTRA_INCLUDES dir1 dir2 ...]
#       [EXTRA_SOURCES file1.cpp ...]
#       [EXTRA_DEFINES -DFLAG1 -DFLAG2 ...]
#       [EXTRA_LIBRARIES lib1 lib2 ...]
#       [VERBOSE_SUMMARY]
#       [INSTALL]
#   )
##########################################################################

function(create_thumbnail_daemon)
    set(options VERBOSE_SUMMARY INSTALL)
    set(oneValueArgs TARGET PREFIX)
    set(multiValueArgs SOURCES FEATURES EXTRA_INCLUDES EXTRA_SOURCES EXTRA_DEFINES EXTRA_LIBRARIES)
    cmake_parse_arguments(CTD "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

    if(NOT CTD_TARGET)
        message(FATAL_ERROR "create_thumbnail_daemon: TARGET is required")
    endif()
    if(NOT CTD_SOURCES)
        message(FATAL_ERROR "create_thumbnail_daemon: SOURCES is required")
    endif()

    # Parse FEATURES list (triplets: NAME "Description" DEFAULT_VALUE)
    set(_feature_list)
    list(LENGTH CTD_FEATURES _feat_len)
    if(_feat_len GREATER 0)
        math(EXPR _feat_max "${_feat_len} - 1")
        set(_idx 0)
        while(NOT _idx GREATER _feat_max)
            # Check if we have enough items for a complete triplet
            math(EXPR _default_idx "${_idx} + 2")
            if(_default_idx GREATER _feat_max)
                break()
            endif()

            # Extract triplet: name, description, default value
            list(GET CTD_FEATURES ${_idx} _feat_name)
            math(EXPR _idx "${_idx} + 1")
            list(GET CTD_FEATURES ${_idx} _feat_desc)
            math(EXPR _idx "${_idx} + 1")
            list(GET CTD_FEATURES ${_idx} _feat_default)
            math(EXPR _idx "${_idx} + 1")

            # Define CMake option for this feature
            option(${_feat_name} "${_feat_desc}" ${_feat_default})
            list(APPEND _feature_list ${_feat_name})
        endwhile()
    endif()

    # Store feature list for aggregated summary
    if(CTD_PREFIX)
        set(${CTD_PREFIX}_DEFINED_OPTIONS "${_feature_list}" CACHE INTERNAL "Feature options for ${CTD_TARGET}")
    endif()

    # Create executable
    add_executable(${CTD_TARGET} ${CTD_SOURCES} ${CTD_EXTRA_SOURCES})

    # Apply base setup
    setup_thumbnail_base(${CTD_TARGET})

    # Auto-detect include directories from sources
    set(_auto_includes ${CMAKE_CURRENT_SOURCE_DIR})
    foreach(_src ${CTD_SOURCES} ${CTD_EXTRA_SOURCES})
        get_filename_component(_src_dir "${_src}" DIRECTORY)
        if(_src_dir AND NOT _src_dir STREQUAL "")
            list(APPEND _auto_includes "${CMAKE_CURRENT_SOURCE_DIR}/${_src_dir}")
        endif()
    endforeach()
    list(REMOVE_DUPLICATES _auto_includes)
    target_include_directories(${CTD_TARGET} PRIVATE ${_auto_includes} ${CTD_EXTRA_INCLUDES})

    # Apply extra defines
    if(CTD_EXTRA_DEFINES)
        target_compile_definitions(${CTD_TARGET} PRIVATE ${CTD_EXTRA_DEFINES})
    endif()

    # Find and link common dependencies (Threads, rdklogger, rtmessage)
    find_package(Threads REQUIRED)
    find_package(rdklogger REQUIRED)
    find_package(rtmessage REQUIRED)
    target_link_libraries(${CTD_TARGET} PRIVATE Threads::Threads)
    link_common_deps(${CTD_TARGET})

    # Feature-based dependency resolution
    set(_needs_opencv FALSE)
    set(_needs_gstreamer FALSE)

    # Check if sources suggest OpenCV usage (heuristic + override)
    if(USE_OPENCV)
        set(_needs_opencv TRUE)
    else()
        foreach(_src ${CTD_SOURCES} ${CTD_EXTRA_SOURCES})
            if(_src MATCHES "smart_thumbnail|opencv|cv|OpenCv")
                set(_needs_opencv TRUE)
                break()
            endif()
        endforeach()
    endif()

    # Map features to packages and link accordingly
    foreach(_feat ${_feature_list})
        if(${_feat})
            # Feature is enabled, find and link corresponding package
            if(_feat STREQUAL "USE_RBUS")
                find_package(rbus REQUIRED)
                if(TARGET rbus::rbus)
                    target_link_libraries(${CTD_TARGET} PRIVATE rbus::rbus)
                endif()
            elseif(_feat STREQUAL "USE_FFMPEG")
                find_package(ffmpeg REQUIRED)
                # Link individual FFmpeg libraries based on actual usage
                if(TARGET ffmpeg::avcodec)
                    target_link_libraries(${CTD_TARGET} PRIVATE ffmpeg::avcodec)
                endif()
                if(TARGET ffmpeg::avformat)
                    target_link_libraries(${CTD_TARGET} PRIVATE ffmpeg::avformat)
                endif()
                if(TARGET ffmpeg::avutil)
                    target_link_libraries(${CTD_TARGET} PRIVATE ffmpeg::avutil)
                endif()
                if(TARGET ffmpeg::swscale)
                    target_link_libraries(${CTD_TARGET} PRIVATE ffmpeg::swscale)
                endif()
            elseif(_feat STREQUAL "USE_HTTPCLIENT")
                find_package(httpclient REQUIRED)
                if(TARGET httpclient::httpclient)
                    target_link_libraries(${CTD_TARGET} PRIVATE httpclient::httpclient)
                endif()
                # Link curl directly (required by CurlHttpClient.cpp, matches original Makefile: AppsRule.mak line 63-67)
                set(_curl_lib "${LIB_PATH}/libcurl.so")
                if(EXISTS "${_curl_lib}")
                    target_link_libraries(${CTD_TARGET} PRIVATE "${_curl_lib}")
                else()
                    message(WARNING "libcurl.so not found at ${_curl_lib}")
                endif()
            elseif(_feat STREQUAL "USE_CONFIGMGR")
                find_package(configmgr REQUIRED)
                # Link configmanager core (which transitively brings in mxml)
                if(TARGET configmgr::configmanager)
                    target_link_libraries(${CTD_TARGET} PRIVATE configmgr::configmanager)
                endif()
                # Add rfcconfig for all targets that use configmgr (all use RFCConfigInit)
                if(TARGET configmgr::rfcconfig)
                    target_link_libraries(${CTD_TARGET} PRIVATE configmgr::rfcconfig)
                endif()
            elseif(_feat STREQUAL "SUPPORT_MXML")
                if(USE_MXML)
                    find_package(mxml REQUIRED)
                    if(TARGET mxml::mxml)
                        target_link_libraries(${CTD_TARGET} PRIVATE mxml::mxml)
                    endif()
                endif()
            elseif(_feat STREQUAL "USE_MFRLIB")
                find_package(mfrlib REQUIRED)
                # Link only mfrapi (which transitively brings in cgicomm, sccomm, asound)
                if(TARGET mfrlib::mfrapi)
                    target_link_libraries(${CTD_TARGET} PRIVATE mfrlib::mfrapi)
                endif()
            elseif(_feat STREQUAL "USE_SYSUTILS")
                find_package(sysutils REQUIRED)
                if(TARGET sysutils::sysutils)
                    target_link_libraries(${CTD_TARGET} PRIVATE sysutils::sysutils)
                endif()
            elseif(_feat STREQUAL "USE_LIBSYSWRAPPER")
                find_package(libsyswrapper REQUIRED)
                if(TARGET libsyswrapper::libsyswrapper)
                    target_link_libraries(${CTD_TARGET} PRIVATE libsyswrapper::libsyswrapper)
                endif()
            elseif(_feat STREQUAL "USE_BREAKPAD")
                find_package(breakpad REQUIRED)
                if(TARGET breakpad::breakpad)
                    target_link_libraries(${CTD_TARGET} PRIVATE breakpad::breakpad)
                    # Ensure BREAKPAD compile definition is set (redundant with INTERFACE_COMPILE_DEFINITIONS, but explicit)
                    target_compile_definitions(${CTD_TARGET} PRIVATE BREAKPAD)
                endif()
            elseif(_feat STREQUAL "USE_FILEUTILS")
                ensure_miscutils(${CTD_TARGET})
            elseif(_feat STREQUAL "USE_TELEMETRY_2")
                find_package(telemetry REQUIRED)
                if(TARGET telemetry::telemetry)
                    target_link_libraries(${CTD_TARGET} PRIVATE telemetry::telemetry)
                endif()
            elseif(_feat STREQUAL "USE_OPENCV")
                set(_needs_opencv TRUE)
            elseif(_feat STREQUAL "USE_GSTREAMER" OR _feat STREQUAL "ENABLE_GSTREAMER")
                set(_needs_gstreamer TRUE)
            elseif(_feat STREQUAL "USE_BASE64")
                find_package(base64 REQUIRED)
                if(TARGET base64::base64)
                    target_link_libraries(${CTD_TARGET} PRIVATE base64::base64)
                endif()
            endif()
        endif()
    endforeach()

    # Handle OpenCV if needed
    if(_needs_opencv)
        find_package(opencv REQUIRED)
        if(TARGET opencv::opencv)
            target_link_libraries(${CTD_TARGET} PRIVATE opencv::opencv)
        endif()
    endif()

    # Handle GStreamer if needed
    if(_needs_gstreamer)
        find_package(gstreamer REQUIRED)
        if(TARGET gstreamer::gstreamer)
            target_link_libraries(${CTD_TARGET} PRIVATE gstreamer::gstreamer)
        endif()
    endif()

    # Setup consumer/plugin includes if using XStreamer
    if(USE_CONSUMER OR USE_PLUGINS)
        setup_consumer_plugin_includes(${CTD_TARGET})
        link_consumer_plugin_libs(${CTD_TARGET})
    endif()

    # Link extra libraries
    if(CTD_EXTRA_LIBRARIES)
        target_link_libraries(${CTD_TARGET} PRIVATE ${CTD_EXTRA_LIBRARIES})
    endif()

    # Verbose summary if requested
    if(CTD_VERBOSE_SUMMARY OR THUMBNAIL_VERBOSE_SUMMARY)
        message(STATUS "=== ${CTD_TARGET} Configuration ===")
        foreach(_feat ${_feature_list})
            message(STATUS "  ${_feat}: ${${_feat}}")
        endforeach()
        message(STATUS "=======================================")
    endif()

    # Install if requested
    if(CTD_INSTALL)
        install(TARGETS ${CTD_TARGET}
            RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
            PERMISSIONS OWNER_READ OWNER_WRITE OWNER_EXECUTE GROUP_READ GROUP_EXECUTE WORLD_READ WORLD_EXECUTE
        )
    endif()
endfunction()
