##########################################################################
# Findffmpeg.cmake
# 
# Creates individual imported targets for FFmpeg libraries:
#   ffmpeg::avcodec, ffmpeg::avformat, ffmpeg::avutil, ffmpeg::swscale
#
# Also provides ffmpeg::ffmpeg aggregated target for backward compatibility.
# eventnotification uses all 4 libraries via NetworkFrameReader.
##########################################################################

if (NOT FFMPEG_FOUND)

include(ThumbnailCommon)

find_package(PkgConfig)

pkg_check_modules(PC_FFMPEG QUIET libavcodec libavformat libavutil libswscale)

# Build search paths - include both opensource and standard usr paths
# XHB1/DBC typically has libs in opensource/, XCam3 may have them in usr/
set(FFMPEG_INCLUDE_SEARCH_PATHS
    ${PC_FFMPEG_INCLUDE_DIRS}
    ${THUMBNAIL_COMMON_INCLUDE_PATHS}
    ${RDK_PROJECT_ROOT_PATH}/usr/include
    ${RDK_PROJECT_ROOT_PATH}/opensource/src/FFmpeg
)

set(FFMPEG_LIBRARY_SEARCH_PATHS
    ${PC_FFMPEG_LIBRARY_DIRS}
    ${THUMBNAIL_COMMON_LIBRARY_PATHS}
    ${RDK_PROJECT_ROOT_PATH}/usr/lib
    ${RDK_PROJECT_ROOT_PATH}/opensource/lib
)

if(THUMBNAIL_CMAKE_VERBOSE)
    message(STATUS "FFmpeg library search paths: ${FFMPEG_LIBRARY_SEARCH_PATHS}")
    message(STATUS "FFmpeg include search paths: ${FFMPEG_INCLUDE_SEARCH_PATHS}")
endif()

message(STATUS "Searching for FFmpeg in: ${FFMPEG_INCLUDE_SEARCH_PATHS}")

# Find include path - CMAKE_PREFIX_PATH is automatically searched by find_path
find_path(FFMPEG_INCLUDE_DIRS NAMES libavcodec/avcodec.h 
    PATHS ${FFMPEG_INCLUDE_SEARCH_PATHS}
    PATH_SUFFIXES "" ffmpeg
    NO_DEFAULT_PATH
)

message(STATUS "FFMPEG_INCLUDE_DIRS result: ${FFMPEG_INCLUDE_DIRS}")

# Fallback to default search (allows CMake to use CMAKE_FIND_ROOT_PATH)
if(NOT FFMPEG_INCLUDE_DIRS)
    find_path(FFMPEG_INCLUDE_DIRS NAMES libavcodec/avcodec.h 
        PATH_SUFFIXES "" ffmpeg)
endif()

# NOTE: FFmpeg headers not staged to sysroot in xcam3
# This fallback searches the FFmpeg build work directory directly.
# TODO: Fix FFmpeg recipe packaging to properly stage headers to sysroot
if(NOT FFMPEG_INCLUDE_DIRS AND RDK_PROJECT_ROOT_PATH)
    string(REGEX MATCH "(.*)/tmp/sysroots" _match "${RDK_PROJECT_ROOT_PATH}")
    if(CMAKE_MATCH_1)
        file(GLOB _ffmpeg_work_dirs "${CMAKE_MATCH_1}/tmp/work/*/ffmpeg/*/FFmpeg-*")
        if(_ffmpeg_work_dirs)
            list(GET _ffmpeg_work_dirs 0 _ffmpeg_src_dir)
            if(EXISTS "${_ffmpeg_src_dir}/libavcodec/avcodec.h")
                set(FFMPEG_INCLUDE_DIRS "${_ffmpeg_src_dir}")
                message(STATUS "WORKAROUND: Using FFmpeg headers from work directory: ${FFMPEG_INCLUDE_DIRS}")
                message(STATUS "  Consider fixing FFmpeg recipe to stage headers properly")
            endif()
        endif()
    endif()
endif()

# Find libraries - CMAKE_PREFIX_PATH is automatically searched by find_library
find_library(AVCODEC_LIB NAMES avcodec PATHS ${FFMPEG_LIBRARY_SEARCH_PATHS})
find_library(AVFORMAT_LIB NAMES avformat PATHS ${FFMPEG_LIBRARY_SEARCH_PATHS})
find_library(AVUTIL_LIB NAMES avutil PATHS ${FFMPEG_LIBRARY_SEARCH_PATHS})
find_library(SWSCALE_LIB NAMES swscale PATHS ${FFMPEG_LIBRARY_SEARCH_PATHS})

# Build library list for compatibility
set(FFMPEG_LIBRARIES)
if(AVCODEC_LIB)
    list(APPEND FFMPEG_LIBRARIES ${AVCODEC_LIB})
endif()
if(AVFORMAT_LIB)
    list(APPEND FFMPEG_LIBRARIES ${AVFORMAT_LIB})
endif()
if(AVUTIL_LIB)
    list(APPEND FFMPEG_LIBRARIES ${AVUTIL_LIB})
endif()
if(SWSCALE_LIB)
    list(APPEND FFMPEG_LIBRARIES ${SWSCALE_LIB})
endif()

# Set deprecated variables
set(FFMPEG_LIBRARY "${AVCODEC_LIB}")
set(FFMPEG_INCLUDE_DIR "${FFMPEG_INCLUDE_DIRS}")

message(STATUS "Final FFMPEG_INCLUDE_DIRS: ${FFMPEG_INCLUDE_DIRS}")
message(STATUS "Final FFMPEG_LIBRARIES: ${FFMPEG_LIBRARIES}")

if(NOT FFMPEG_INCLUDE_DIRS)
    message(FATAL_ERROR "FFmpeg libraries found but headers not found! Searched in: ${FFMPEG_INCLUDE_SEARCH_PATHS}")
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(ffmpeg DEFAULT_MSG FFMPEG_LIBRARIES)

# Create individual imported targets per library (not aggregated)
if (FFMPEG_FOUND)
    # ffmpeg::avcodec
    if(AVCODEC_LIB AND NOT TARGET ffmpeg::avcodec)
        add_library(ffmpeg::avcodec UNKNOWN IMPORTED)
        set_target_properties(ffmpeg::avcodec PROPERTIES
            IMPORTED_LOCATION "${AVCODEC_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_FFMPEG_CFLAGS_OTHER}")
        if(FFMPEG_INCLUDE_DIRS)
            set_property(TARGET ffmpeg::avcodec PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${FFMPEG_INCLUDE_DIRS}")
        endif()
    endif()
    
    # ffmpeg::avformat (depends on avcodec and avutil)
    if(AVFORMAT_LIB AND NOT TARGET ffmpeg::avformat)
        add_library(ffmpeg::avformat UNKNOWN IMPORTED)
        set_target_properties(ffmpeg::avformat PROPERTIES
            IMPORTED_LOCATION "${AVFORMAT_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_FFMPEG_CFLAGS_OTHER}")
        if(FFMPEG_INCLUDE_DIRS)
            set_property(TARGET ffmpeg::avformat PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${FFMPEG_INCLUDE_DIRS}")
        endif()
        # avformat depends on avcodec and avutil
        if(TARGET ffmpeg::avcodec)
            set_property(TARGET ffmpeg::avformat APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES ffmpeg::avcodec)
        endif()
    endif()
    
    # ffmpeg::avutil (base library, no dependencies)
    if(AVUTIL_LIB AND NOT TARGET ffmpeg::avutil)
        add_library(ffmpeg::avutil UNKNOWN IMPORTED)
        set_target_properties(ffmpeg::avutil PROPERTIES
            IMPORTED_LOCATION "${AVUTIL_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_FFMPEG_CFLAGS_OTHER}")
        if(FFMPEG_INCLUDE_DIRS)
            set_property(TARGET ffmpeg::avutil PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${FFMPEG_INCLUDE_DIRS}")
        endif()
    endif()
    
    # ffmpeg::swscale (depends on avutil)
    if(SWSCALE_LIB AND NOT TARGET ffmpeg::swscale)
        add_library(ffmpeg::swscale UNKNOWN IMPORTED)
        set_target_properties(ffmpeg::swscale PROPERTIES
            IMPORTED_LOCATION "${SWSCALE_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_FFMPEG_CFLAGS_OTHER}")
        if(FFMPEG_INCLUDE_DIRS)
            set_property(TARGET ffmpeg::swscale PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${FFMPEG_INCLUDE_DIRS}")
        endif()
        # swscale depends on avutil
        if(TARGET ffmpeg::avutil)
            set_property(TARGET ffmpeg::swscale APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES ffmpeg::avutil)
        endif()
    endif()
    
    # Legacy aggregated target for backward compatibility
    if(NOT TARGET ffmpeg::ffmpeg)
        add_library(ffmpeg::ffmpeg INTERFACE IMPORTED)
        set_property(TARGET ffmpeg::ffmpeg PROPERTY
            INTERFACE_LINK_LIBRARIES ffmpeg::avcodec ffmpeg::avformat ffmpeg::avutil ffmpeg::swscale)
    endif()
endif()

mark_as_advanced(FFMPEG_INCLUDE_DIR FFMPEG_LIBRARY
                 FFMPEG_INCLUDE_DIRS FFMPEG_LIBRARIES
                 AVCODEC_LIB AVFORMAT_LIB AVUTIL_LIB SWSCALE_LIB)

endif()

