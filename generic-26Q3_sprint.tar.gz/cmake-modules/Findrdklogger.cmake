##########################################################################
# Findrdklogger.cmake
#
# Find RDK logging library.
# Creates imported target: rdklogger::rdklogger
##########################################################################

if (NOT RDKLOGGER_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_RDKLOGGER QUIET rdklogger)

find_path(RDKLOGGER_INCLUDE_DIRS NAMES rdk_debug.h PATHS ${PC_RDKLOGGER_INCLUDE_DIRS})
find_library(RDKLOGGER_LIBRARIES NAMES rdkloggers PATHS ${PC_RDKLOGGER_LIBRARY_DIRS})

# Set deprecated variables
set(RDKLOGGER_LIBRARY "${RDKLOGGER_LIBRARIES}")
set(RDKLOGGER_INCLUDE_DIR "${RDKLOGGER_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(rdklogger DEFAULT_MSG RDKLOGGER_LIBRARIES RDKLOGGER_INCLUDE_DIRS)

if (RDKLOGGER_FOUND AND NOT TARGET rdklogger::rdklogger)
    add_library(rdklogger::rdklogger UNKNOWN IMPORTED)
    set_target_properties(rdklogger::rdklogger PROPERTIES
                          IMPORTED_LOCATION "${RDKLOGGER_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_RDKLOGGER_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${RDKLOGGER_INCLUDE_DIRS}")
endif()

mark_as_advanced(RDKLOGGER_INCLUDE_DIR RDKLOGGER_LIBRARY
                 RDKLOGGER_INCLUDE_DIRS RDKLOGGER_LIBRARIES)

endif()
