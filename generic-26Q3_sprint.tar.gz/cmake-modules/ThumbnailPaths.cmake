##########################################################################
# ThumbnailPaths.cmake
#
# Purpose:
#   Centralized path configuration for Yocto and non-Yocto RDK builds.
#   Automatically detects build environment and configures appropriate
#   library search paths, include directories, and install destinations.
#
# Responsibilities:
#   - Detects Yocto vs non-Yocto build environment
#   - Sets LIB_PATH and SHADOW_ROOT_LIB_PATH for non-Yocto builds
#   - Configures CMAKE_PREFIX_PATH for find_package() calls
#   - Sets up CMAKE_INSTALL_PREFIX based on RDK_SDROOT
#   - Includes GNUInstallDirs for standard install directories
#   - Provides find_thumbnail_library() helper function
#
# Usage:
#   Include this file early in the root CMakeLists.txt:
#     set(CMAKE_MODULE_PATH ${CMAKE_CURRENT_SOURCE_DIR}/cmake-modules ${CMAKE_MODULE_PATH})
#     include(ThumbnailPaths)
#
# Variables Set:
#   IS_YOCTO_BUILD           - Boolean: TRUE if building with Yocto
#   RDK_PROJECT_ROOT_PATH    - Path to RDK project root
#   LIB_PATH                 - Primary library search path (non-Yocto only)
#   SHADOW_ROOT_LIB_PATH     - Secondary library path (non-Yocto only)
#   AMBA_DIR_PATH            - Ambarella SDK path (non-Yocto only)
#   AMBA_ARCH                - Architecture subdirectory (arch_s5l/arch_s2l/arch_s3l)
#   CMAKE_PREFIX_PATH        - Updated with RDK SDK paths
#   CMAKE_INSTALL_PREFIX     - Set to RDK_SDROOT/usr/local or /usr/local
##########################################################################

# Prevent multiple inclusion
if(NOT THUMBNAIL_PATHS_INCLUDED)
set(THUMBNAIL_PATHS_INCLUDED TRUE)

##########################################################################
# Environment Detection
##########################################################################

# Detect if this is a Yocto build
if(DEFINED ENV{OECORE_NATIVE_SYSROOT} OR DEFINED ENV{OECORE_TARGET_SYSROOT})
    set(IS_YOCTO_BUILD TRUE CACHE INTERNAL "Building with Yocto")
    message(STATUS "Detected Yocto build environment")
else()
    set(IS_YOCTO_BUILD FALSE CACHE INTERNAL "Building without Yocto")
    message(STATUS "Detected non-Yocto build environment")
endif()

# Detect RDK project root
if(DEFINED ENV{RDK_PROJECT_ROOT_PATH})
    set(RDK_PROJECT_ROOT_PATH "$ENV{RDK_PROJECT_ROOT_PATH}" CACHE PATH "RDK project root path")
elseif(NOT DEFINED RDK_PROJECT_ROOT_PATH)
    # Try to detect from current source directory structure
    get_filename_component(DETECTED_ROOT "${CMAKE_CURRENT_SOURCE_DIR}/../.." ABSOLUTE)
    if(EXISTS "${DETECTED_ROOT}/sdk")
        set(RDK_PROJECT_ROOT_PATH "${DETECTED_ROOT}" CACHE PATH "RDK project root path")
        message(STATUS "Auto-detected RDK_PROJECT_ROOT_PATH: ${RDK_PROJECT_ROOT_PATH}")
    endif()
endif()

##########################################################################
# Library and Include Paths
##########################################################################

if(IS_YOCTO_BUILD)
    # Yocto builds use sysroot paths set by the toolchain
    # Libraries are found via CMAKE_FIND_ROOT_PATH
    set(LIB_PATH "" CACHE PATH "Library path (handled by Yocto sysroot)")
    set(SHADOW_ROOT_LIB_PATH "" CACHE PATH "Shadow root library path (not used in Yocto)")
    set(AMBA_DIR_PATH "" CACHE PATH "Ambarella SDK path (not used in Yocto)")
    set(AMBA_ARCH "" CACHE STRING "Ambarella architecture (not used in Yocto)")

else()
    # Non-Yocto builds: Use RDK SDK paths
    if(RDK_PROJECT_ROOT_PATH)
        set(LIB_PATH "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/ramdisk/usr/lib"
            CACHE PATH "Primary library search path")
        set(SHADOW_ROOT_LIB_PATH "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/vendor/img/fs/shadow_root/usr/lib"
            CACHE PATH "Secondary (shadow root) library search path")
        set(AMBA_DIR_PATH "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/amba"
            CACHE PATH "Ambarella SDK path")

        # Set architecture-specific path based on model
        if(XCAM_MODEL STREQUAL "XHB1")
            set(AMBA_ARCH "arch_s5l" CACHE STRING "Ambarella architecture")
        elseif(XCAM_MODEL STREQUAL "XHC3")
            set(AMBA_ARCH "arch_s2l" CACHE STRING "Ambarella architecture")
        elseif(XCAM_MODEL STREQUAL "SCHC2")
            set(AMBA_ARCH "arch_s3l" CACHE STRING "Ambarella architecture")
        else()
            set(AMBA_ARCH "arch_s3l" CACHE STRING "Ambarella architecture (default)")
        endif()

        # Add to CMAKE_PREFIX_PATH for find_package() - use CACHE FORCE to ensure it propagates
        set(CMAKE_PREFIX_PATH
            "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/ramdisk/usr"
            "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/ramdisk/usr/local"
            ${CMAKE_PREFIX_PATH}
            CACHE PATH "CMake prefix path" FORCE)

        # Add to link directories for -l flags
        link_directories(${LIB_PATH})
        if(EXISTS "${SHADOW_ROOT_LIB_PATH}")
            link_directories(${SHADOW_ROOT_LIB_PATH})
        endif()
        
        message(STATUS "ThumbnailPaths: LIB_PATH = ${LIB_PATH}")
        message(STATUS "ThumbnailPaths: AMBA_DIR_PATH = ${AMBA_DIR_PATH}")
        message(STATUS "ThumbnailPaths: AMBA_ARCH = ${AMBA_ARCH}")
    else()
        message(WARNING "RDK_PROJECT_ROOT_PATH not set - library paths may be incomplete")
    endif()
endif()

##########################################################################
# Install Paths
##########################################################################

# Detect RDK_SDROOT for install prefix
if(DEFINED ENV{RDK_SDROOT})
    set(RDK_SDROOT "$ENV{RDK_SDROOT}" CACHE PATH "RDK SD root path")
elseif(NOT DEFINED RDK_SDROOT)
    if(RDK_PROJECT_ROOT_PATH)
        set(RDK_SDROOT "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/ramdisk" CACHE PATH "RDK SD root path")
    endif()
endif()

# Set CMAKE_INSTALL_PREFIX if not already set by user
if(CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)
    if(IS_YOCTO_BUILD)
        # Yocto handles install prefix via DESTDIR
        set(CMAKE_INSTALL_PREFIX "/usr/local" CACHE PATH "Install prefix" FORCE)
    elseif(RDK_SDROOT)
        # Non-Yocto: Install to RDK_SDROOT/usr/local (matching original Makefile)
        set(CMAKE_INSTALL_PREFIX "${RDK_SDROOT}/usr/local" CACHE PATH "Install prefix" FORCE)
    else()
        # Fallback
        set(CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}/usr/local" CACHE PATH "Install prefix" FORCE)
    endif()
endif()

# Include GNUInstallDirs for standard directory variables
include(GNUInstallDirs)

# For non-Yocto builds, explicitly set bindir to ensure correct path
# GNUInstallDirs sets CMAKE_INSTALL_BINDIR to "bin" which becomes relative
# to PREFIX, but we need to ensure it resolves to usr/local/bin on device
if(NOT IS_YOCTO_BUILD AND RDK_SDROOT)
    # Override CMAKE_INSTALL_BINDIR to be absolute path for non-Yocto
    set(CMAKE_INSTALL_BINDIR "${RDK_SDROOT}/usr/local/bin" CACHE PATH "Binary install directory" FORCE)
endif()

##########################################################################
# Helper Function: Find Library with Fallback
##########################################################################

# find_thumbnail_library(
#     OUTPUT_VAR variable_name
#     LIBRARY library_name
#     [REQUIRED]
# )
#
# Searches for a library in standard paths, with special handling for
# non-Yocto builds using direct paths.
function(find_thumbnail_library)
    cmake_parse_arguments(FTL "REQUIRED" "OUTPUT_VAR;LIBRARY" "" ${ARGN})

    if(NOT FTL_OUTPUT_VAR OR NOT FTL_LIBRARY)
        message(FATAL_ERROR "find_thumbnail_library: OUTPUT_VAR and LIBRARY are required")
    endif()

    if(IS_YOCTO_BUILD)
        # Use standard find_library
        find_library(${FTL_OUTPUT_VAR} ${FTL_LIBRARY})
    else()
        # Try direct path first for non-Yocto
        set(_lib_path "${LIB_PATH}/lib${FTL_LIBRARY}.so")
        if(EXISTS "${_lib_path}")
            set(${FTL_OUTPUT_VAR} "${_lib_path}" PARENT_SCOPE)
            return()
        endif()

        # Fallback to standard search
        find_library(${FTL_OUTPUT_VAR} ${FTL_LIBRARY})
    endif()

    if(FTL_REQUIRED AND NOT ${FTL_OUTPUT_VAR})
        message(FATAL_ERROR "Required library not found: ${FTL_LIBRARY}")
    endif()

    # Propagate to parent scope
    set(${FTL_OUTPUT_VAR} "${${FTL_OUTPUT_VAR}}" PARENT_SCOPE)
endfunction()

endif() # THUMBNAIL_PATHS_INCLUDED