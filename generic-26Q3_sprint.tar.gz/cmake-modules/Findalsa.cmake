##########################################################################
# Findalsa.cmake
#
# Find ALSA (Advanced Linux Sound Architecture) library.
# Creates imported target: alsa::alsa
##########################################################################

if (NOT ALSA_FOUND)

include(ThumbnailCommon)

find_package(PkgConfig)

pkg_check_modules(PC_ALSA QUIET alsa)

find_path(ALSA_INCLUDE_DIRS NAMES alsa/asoundlib.h PATHS ${PC_ALSA_INCLUDE_DIRS} ${THUMBNAIL_COMMON_INCLUDE_PATHS})
find_library(ALSA_LIBRARIES NAMES asound PATHS ${PC_ALSA_LIBRARY_DIRS} ${THUMBNAIL_COMMON_LIBRARY_PATHS})

# Set deprecated variables
set(ALSA_LIBRARY "${ALSA_LIBRARIES}")
set(ALSA_INCLUDE_DIR "${ALSA_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(alsa DEFAULT_MSG ALSA_LIBRARIES ALSA_INCLUDE_DIRS)

if (ALSA_FOUND AND NOT TARGET alsa::alsa)
    add_library(alsa::alsa UNKNOWN IMPORTED)
    set_target_properties(alsa::alsa PROPERTIES
                          IMPORTED_LOCATION "${ALSA_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_ALSA_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${ALSA_INCLUDE_DIRS}")
endif()

mark_as_advanced(ALSA_INCLUDE_DIR ALSA_LIBRARY
                 ALSA_INCLUDE_DIRS ALSA_LIBRARIES)

endif()
