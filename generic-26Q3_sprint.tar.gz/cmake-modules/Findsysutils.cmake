##########################################################################
# Findsysutils.cmake
#
# Find system utilities library.
# Creates imported target: sysutils::sysutils
##########################################################################

if (NOT SYSUTILS_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_SYSUTILS QUIET sysutils)

find_path(SYSUTILS_INCLUDE_DIRS NAMES sysUtils.h PATHS ${PC_SYSUTILS_INCLUDE_DIRS})
find_library(SYSUTILS_LIBRARIES NAMES sysutils PATHS ${PC_SYSUTILS_LIBRARY_DIRS})

# Set deprecated variables
set(SYSUTILS_LIBRARY "${SYSUTILS_LIBRARIES}")
set(SYSUTILS_INCLUDE_DIR "${SYSUTILS_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(sysutils DEFAULT_MSG SYSUTILS_LIBRARIES SYSUTILS_INCLUDE_DIRS)

if (SYSUTILS_FOUND AND NOT TARGET sysutils::sysutils)
    add_library(sysutils::sysutils UNKNOWN IMPORTED)
    set_target_properties(sysutils::sysutils PROPERTIES
                          IMPORTED_LOCATION "${SYSUTILS_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_SYSUTILS_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${SYSUTILS_INCLUDE_DIRS}")
endif()

mark_as_advanced(SYSUTILS_INCLUDE_DIR SYSUTILS_LIBRARY
                 SYSUTILS_INCLUDE_DIRS SYSUTILS_LIBRARIES)

endif()
