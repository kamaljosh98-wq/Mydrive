##########################################################################
# Findlibsyswrapper.cmake
#
# Find secure wrapper library for system calls.
# Creates imported target: libsyswrapper::libsyswrapper
##########################################################################

if (NOT LIBSYSWRAPPER_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_LIBSYSWRAPPER QUIET libsyswrapper)

# Manual search paths for non-Yocto builds
set(_LIBSYSWRAPPER_SEARCH_PATHS
    ${PC_LIBSYSWRAPPER_INCLUDE_DIRS}
    ${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/ramdisk/usr/include
    ${RDK_PROJECT_ROOT_PATH}/libsyswrapper/source
)

set(_LIBSYSWRAPPER_LIB_SEARCH_PATHS
    ${PC_LIBSYSWRAPPER_LIBRARY_DIRS}
    ${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/vendor/img/fs/shadow_root/usr/lib
    ${RDK_PROJECT_ROOT_PATH}/libsyswrapper/source/.libs
)

find_path(LIBSYSWRAPPER_INCLUDE_DIRS NAMES secure_wrapper.h PATHS ${_LIBSYSWRAPPER_SEARCH_PATHS})
find_library(LIBSYSWRAPPER_LIBRARIES NAMES secure_wrapper PATHS ${_LIBSYSWRAPPER_LIB_SEARCH_PATHS})

message(STATUS "Findlibsyswrapper: LIBSYSWRAPPER_INCLUDE_DIRS = ${LIBSYSWRAPPER_INCLUDE_DIRS}")
message(STATUS "Findlibsyswrapper: LIBSYSWRAPPER_LIBRARIES = ${LIBSYSWRAPPER_LIBRARIES}")

# Set deprecated variables
set(LIBSYSWRAPPER_LIBRARY "${LIBSYSWRAPPER_LIBRARIES}")
set(LIBSYSWRAPPER_INCLUDE_DIR "${LIBSYSWRAPPER_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(libsyswrapper DEFAULT_MSG LIBSYSWRAPPER_LIBRARIES LIBSYSWRAPPER_INCLUDE_DIRS)

if (LIBSYSWRAPPER_FOUND AND NOT TARGET libsyswrapper::libsyswrapper)
    add_library(libsyswrapper::libsyswrapper UNKNOWN IMPORTED)
    set_target_properties(libsyswrapper::libsyswrapper PROPERTIES
                          IMPORTED_LOCATION "${LIBSYSWRAPPER_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_LIBSYSWRAPPER_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${LIBSYSWRAPPER_INCLUDE_DIRS}")
endif()

mark_as_advanced(LIBSYSWRAPPER_INCLUDE_DIR LIBSYSWRAPPER_LIBRARY
                 LIBSYSWRAPPER_INCLUDE_DIRS LIBSYSWRAPPER_LIBRARIES)

endif()
