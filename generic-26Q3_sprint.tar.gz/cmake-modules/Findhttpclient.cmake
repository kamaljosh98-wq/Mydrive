##########################################################################
# Findhttpclient.cmake
# 
# Creates individual imported targets for HTTP client libraries:
#   httpclient::curl, httpclient::httpclient
#
# Also provides httpclient::httpclient aggregated target for backward compatibility.
# Note: log4c and zlib have their own separate find modules (Findlog4c.cmake, Findzlib.cmake)
##########################################################################

if (NOT HTTPCLIENT_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_HTTPCLIENT QUIET httpclient)
pkg_check_modules(PC_CURL QUIET libcurl)

find_path(HTTPCLIENT_INCLUDE_DIRS NAMES httpclient.h PATHS ${PC_HTTPCLIENT_INCLUDE_DIRS})
find_path(CURL_INCLUDE_DIRS NAMES curl/curl.h PATHS ${PC_CURL_INCLUDE_DIRS})
find_library(CURL_LIBRARY NAMES curl PATHS ${PC_CURL_LIBRARY_DIRS})
find_library(HTTPCLIENT_LIBRARY NAMES httpclient PATHS ${PC_HTTPCLIENT_LIBRARY_DIRS})

# Build library list for compatibility
set(HTTPCLIENT_LIBRARIES)
if(CURL_LIBRARY)
    list(APPEND HTTPCLIENT_LIBRARIES ${CURL_LIBRARY})
endif()
if(HTTPCLIENT_LIBRARY)
    list(APPEND HTTPCLIENT_LIBRARIES ${HTTPCLIENT_LIBRARY})
endif()

# Set deprecated variables
set(HTTPCLIENT_LIBRARY "${HTTPCLIENT_LIBRARY}")
set(HTTPCLIENT_INCLUDE_DIR "${HTTPCLIENT_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(httpclient DEFAULT_MSG HTTPCLIENT_LIBRARIES)

# Create individual imported targets per library (not aggregated)
if (HTTPCLIENT_FOUND)
    # httpclient::curl (libcurl library)
    if(CURL_LIBRARY AND NOT TARGET httpclient::curl)
        add_library(httpclient::curl UNKNOWN IMPORTED)
        set_target_properties(httpclient::curl PROPERTIES
            IMPORTED_LOCATION "${CURL_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_CURL_CFLAGS_OTHER}")
        if(CURL_INCLUDE_DIRS)
            set_property(TARGET httpclient::curl PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${CURL_INCLUDE_DIRS}")
        endif()
    endif()
    
    # httpclient::httpclient (httpclient library, depends on curl)
    if(HTTPCLIENT_LIBRARY AND NOT TARGET httpclient::httpclient)
        add_library(httpclient::httpclient UNKNOWN IMPORTED)
        set_target_properties(httpclient::httpclient PROPERTIES
            IMPORTED_LOCATION "${HTTPCLIENT_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_HTTPCLIENT_CFLAGS_OTHER}")
        if(HTTPCLIENT_INCLUDE_DIRS)
            set_property(TARGET httpclient::httpclient PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${HTTPCLIENT_INCLUDE_DIRS}")
        endif()
        # httpclient depends on curl - ensure curl is always linked transitively
        if(TARGET httpclient::curl)
            set_property(TARGET httpclient::httpclient PROPERTY
                INTERFACE_LINK_LIBRARIES httpclient::curl)
        elseif(CURL_LIBRARY)
            # Fallback: link curl directly if target doesn't exist
            set_property(TARGET httpclient::httpclient PROPERTY
                INTERFACE_LINK_LIBRARIES "${CURL_LIBRARY}")
        endif()
    endif()
endif()

mark_as_advanced(HTTPCLIENT_INCLUDE_DIR HTTPCLIENT_LIBRARY
                 HTTPCLIENT_INCLUDE_DIRS HTTPCLIENT_LIBRARIES
                 CURL_INCLUDE_DIRS CURL_LIBRARY)

endif()
