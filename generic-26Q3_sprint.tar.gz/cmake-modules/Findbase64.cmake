##########################################################################
# Findbase64.cmake
#
# Find Base64 encoding library (trower-base64).
# Creates imported target: base64::base64
##########################################################################

if (NOT BASE64_FOUND)

include(ThumbnailCommon)

find_package(PkgConfig)

pkg_check_modules(PC_BASE64 QUIET base64 trower-base64)

find_path(BASE64_INCLUDE_DIRS NAMES base64.h 
    PATHS ${PC_BASE64_INCLUDE_DIRS} ${THUMBNAIL_COMMON_INCLUDE_PATHS}
    PATH_SUFFIXES "" trower-base64)
find_library(BASE64_LIBRARIES NAMES base64 trower-base64
    PATHS ${PC_BASE64_LIBRARY_DIRS} ${THUMBNAIL_COMMON_LIBRARY_PATHS})

# Set deprecated variables
set(BASE64_LIBRARY "${BASE64_LIBRARIES}")
set(BASE64_INCLUDE_DIR "${BASE64_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(base64 DEFAULT_MSG BASE64_LIBRARIES BASE64_INCLUDE_DIRS)

if (BASE64_FOUND AND NOT TARGET base64::base64)
    add_library(base64::base64 UNKNOWN IMPORTED)
    set_target_properties(base64::base64 PROPERTIES
                          IMPORTED_LOCATION "${BASE64_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_BASE64_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${BASE64_INCLUDE_DIRS}")
endif()

mark_as_advanced(BASE64_INCLUDE_DIR BASE64_LIBRARY
                 BASE64_INCLUDE_DIRS BASE64_LIBRARIES)

endif()
