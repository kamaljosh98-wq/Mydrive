##########################################################################
# Findrtmessage.cmake
#
# Find RT Message library (depends on cjson).
# Creates imported target: rtmessage::rtmessage
##########################################################################

if (NOT RTMESSAGE_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_RTMESSAGE QUIET rtmessage)

find_path(RTMESSAGE_INCLUDE_DIRS NAMES rtMessage.h PATHS ${PC_RTMESSAGE_INCLUDE_DIRS} PATH_SUFFIXES rtmessage)
find_library(RTMESSAGE_LIBRARIES NAMES rtMessage PATHS ${PC_RTMESSAGE_LIBRARY_DIRS})

# RTMessage depends on cjson
find_library(CJSON_LIBRARY NAMES cjson)

# Set deprecated variables
set(RTMESSAGE_LIBRARY "${RTMESSAGE_LIBRARIES}")
set(RTMESSAGE_INCLUDE_DIR "${RTMESSAGE_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(rtmessage DEFAULT_MSG RTMESSAGE_LIBRARIES RTMESSAGE_INCLUDE_DIRS)

if (RTMESSAGE_FOUND AND NOT TARGET rtmessage::rtmessage)
    add_library(rtmessage::rtmessage UNKNOWN IMPORTED)
    set_target_properties(rtmessage::rtmessage PROPERTIES
                          IMPORTED_LOCATION "${RTMESSAGE_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_RTMESSAGE_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${RTMESSAGE_INCLUDE_DIRS}")
    # Link cjson dependency
    if(CJSON_LIBRARY)
        set_property(TARGET rtmessage::rtmessage APPEND PROPERTY
                     INTERFACE_LINK_LIBRARIES "${CJSON_LIBRARY}")
    endif()
endif()

mark_as_advanced(RTMESSAGE_INCLUDE_DIR RTMESSAGE_LIBRARY
                 RTMESSAGE_INCLUDE_DIRS RTMESSAGE_LIBRARIES CJSON_LIBRARY)

endif()
