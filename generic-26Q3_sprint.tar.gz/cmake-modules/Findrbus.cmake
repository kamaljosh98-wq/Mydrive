##########################################################################
# Findrbus.cmake
#
# Find RDK Bus (RBUS) messaging library.
# Creates imported target: rbus::rbus
##########################################################################

if (NOT RBUS_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_RBUS QUIET rbus)

find_path(RBUS_INCLUDE_DIRS NAMES rbus.h PATHS ${PC_RBUS_INCLUDE_DIRS} PATH_SUFFIXES rbus)
find_library(RBUS_LIBRARIES NAMES rbus PATHS ${PC_RBUS_LIBRARY_DIRS})
find_program(RBUS_EXECUTABLE NAMES rtrouted)

# Set deprecated variables
set(RBUS_LIBRARY "${RBUS_LIBRARIES}")
set(RBUS_INCLUDE_DIR "${RBUS_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(rbus DEFAULT_MSG RBUS_LIBRARIES RBUS_INCLUDE_DIRS)

if (RBUS_FOUND AND NOT TARGET rbus::rbus)
    add_library(rbus::rbus UNKNOWN IMPORTED)
    set_target_properties(rbus::rbus PROPERTIES
                          IMPORTED_LOCATION "${RBUS_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_RBUS_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${RBUS_INCLUDE_DIRS}")
endif()

mark_as_advanced(RBUS_INCLUDE_DIR RBUS_LIBRARY
                 RBUS_INCLUDE_DIRS RBUS_LIBRARIES)

endif()
