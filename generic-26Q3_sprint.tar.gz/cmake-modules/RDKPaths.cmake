# RDKPaths.cmake

# Detect RDK_TOOLCHAIN_PATH from environment if not set
if(NOT DEFINED RDK_TOOLCHAIN_PATH AND DEFINED ENV{RDK_TOOLCHAIN_PATH})
    set(RDK_TOOLCHAIN_PATH "$ENV{RDK_TOOLCHAIN_PATH}")
endif()

if(RDKC_YOCTO)

    set(INCLUDE_DIR_PATH
        "${YOCTO_SYSROOT}/usr/include"
        CACHE INTERNAL ""
    )

    set(LIB_PATH
        "${YOCTO_SYSROOT}/usr/lib"
        CACHE INTERNAL ""
    )

    set(SHADOW_ROOT_LIB_PATH
        "${YOCTO_SYSROOT}/sdk/fsroot/src/vendor/img/fs/shadow_root/usr/lib"
        CACHE INTERNAL ""
    )

    set(AMBA_DIR_PATH
        "${YOCTO_SYSROOT}/usr/include/amba"
        CACHE INTERNAL ""
    )

    set(AMBA_INCLUDE_DIR
        "${AMBA_DIR_PATH}/include"
        CACHE INTERNAL ""
    )

    if(XCAM_MODEL STREQUAL "XHB1")
        set(ALSA_INCLUDE_DIR
            "${YOCTO_SYSROOT}/sdk/fsroot/src/amba/prebuild/third-party/armv8-a/alsa-lib/include"
            CACHE INTERNAL ""
        )

        set(ALSA_LIB_PATH
            "${YOCTO_SYSROOT}/sdk/fsroot/src/amba/prebuild/third-party/armv8-a/alsa-lib/usr/lib"
            CACHE INTERNAL ""
        )
    elseif(XCAM_MODEL STREQUAL "XHC3")
        set(ALSA_INCLUDE_DIR
            "${YOCTO_SYSROOT}/sdk/fsroot/src/amba/prebuild/third-party/armv7-a-hf/alsa-lib/include"
            CACHE INTERNAL ""
        )

        set(ALSA_LIB_PATH
            "${YOCTO_SYSROOT}/sdk/fsroot/src/amba/prebuild/third-party/armv7-a-hf/alsa-lib/usr/lib"
            CACHE INTERNAL ""
        )
    endif()

else()  # NON-YOCTO

    set(INCLUDE_DIR_PATH
        "${RDK_FSROOT_PATH}/usr/include"
        CACHE INTERNAL ""
    )

    set(LIB_PATH
        "${RDK_FSROOT_PATH}/usr/lib"
        CACHE INTERNAL ""
    )

    set(SCCOMM_LIB_DIR
        "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/share/libsccomm/bin"
        CACHE INTERNAL ""
    )

    set(SCCOMM_HEADERS_DIR
        "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/share/libsccomm/inc"
        CACHE INTERNAL ""
    )

    set(SC_CONFIG_DIR
        "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/share/sc_config"
        CACHE INTERNAL ""
    )

    set(AMBA_DIR_PATH
        "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/amba"
        CACHE INTERNAL ""
    )

    set(AMBA_INCLUDE_DIR
        "${AMBA_DIR_PATH}/include"
        CACHE INTERNAL ""
    )

    set(ALSA_INCLUDE_DIR
        "${AMBA_DIR_PATH}/prebuild/third-party/armv7-a-hf/alsa-lib/include"
        CACHE INTERNAL ""
    )

    set(ALSA_LIB_PATH
        "${AMBA_DIR_PATH}/prebuild/third-party/armv7-a-hf/alsa-lib/usr/lib"
        CACHE INTERNAL ""
    )

    set(SHADOW_ROOT_LIB_PATH
        "${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/vendor/img/fs/shadow_root/usr/lib"
        CACHE INTERNAL ""
    )

    set(OPENSRC_LIB_PATH
        "${RDK_PROJECT_ROOT_PATH}/opensource/lib"
        CACHE INTERNAL ""
    )

    set(OPENSRC_INCLUDE_PATH
        "${RDK_PROJECT_ROOT_PATH}/opensource/include"
        CACHE INTERNAL ""
    )

    set(TOOLCHAIN_LIB_PATH
        "${RDK_TOOLCHAIN_PATH}/linaro-armv7ahf-2015.11-gcc5.2/arm-linux-gnueabihf/libc/usr/lib"
        CACHE INTERNAL ""
    )

    set (BGS_LIB_PATH
        "${RDK_PROJECT_ROOT_PATH}/video-analytics/XCV/build"
    )

endif()
