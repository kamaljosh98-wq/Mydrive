if (NOT UTILITY_FOUND)
    find_package(PkgConfig)
    if (PKG_CONFIG_FOUND)
        pkg_check_modules(UTILITY_PC QUIET utility)
    endif()

    find_library(SYSUTILS_LIB NAMES sysutils HINTS ${PC_UTILITY_LIBRARY_DIRS})
    if (SYSUTILS_LIB AND NOT TARGET utility::sysutils)
        add_library(utility::sysutils UNKNOWN IMPORTED)
        set_target_properties(utility::sysutils PROPERTIES
            IMPORTED_LOCATION "${SYSUTILS_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${UTILITY_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_UTILITY_CFLAGS_OTHER}"
        )
        mark_as_advanced(SYSUTILS_LIB)
    endif()

    find_library(MISCUTILS_LIB NAMES miscutils HINTS ${PC_UTILITY_LIBRARY_DIRS})
    if (MISCUTILS_LIB AND NOT TARGET utility::miscutils)
        add_library(utility::miscutils UNKNOWN IMPORTED)
        set_target_properties(utility::miscutils PROPERTIES
            IMPORTED_LOCATION "${MISCUTILS_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${UTILITY_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_UTILITY_CFLAGS_OTHER}"
        )
        mark_as_advanced(MISCUTILS_LIB)
    endif()

    find_library(RFCCONFIG_LIB NAMES rfcconfig HINTS ${PC_UTILITY_LIBRARY_DIRS})
    if (RFCCONFIG_LIB AND NOT TARGET utility::rfcconfig)
        add_library(utility::rfcconfig UNKNOWN IMPORTED)
        set_target_properties(utility::rfcconfig PROPERTIES
            IMPORTED_LOCATION "${RFCCONFIG_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${UTILITY_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_UTILITY_CFLAGS_OTHER}"
        )
        mark_as_advanced(RFCCONFIG_LIB)
    endif()

    find_library(CURLUTILS_LIB NAMES curlutils HINTS ${PC_UTILITY_LIBRARY_DIRS})
    if (CURLUTILS_LIB AND NOT TARGET utility::curlutils)
        add_library(utility::curlutils UNKNOWN IMPORTED)
        set_target_properties(utility::curlutils PROPERTIES
            IMPORTED_LOCATION "${CURLUTILS_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${UTILITY_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_UTILITY_CFLAGS_OTHER}"
        )
        mark_as_advanced(CURLUTILS_LIB)
    endif()

    find_library(RDKDYNLOG_LIB NAMES rdkdynamiclog HINTS ${PC_UTILITY_LIBRARY_DIRS})
    if (RDKDYNLOG_LIB AND NOT TARGET utility::rdkdynamiclog)
        add_library(utility::rdkdynamiclog UNKNOWN IMPORTED)
        set_target_properties(utility::rdkdynamiclog PROPERTIES
            IMPORTED_LOCATION "${RDKDYNLOG_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${UTILITY_INCLUDE_DIRS}"
            INTERFACE_COMPILE_OPTIONS "${PC_UTILITY_CFLAGS_OTHER}"
        )
        mark_as_advanced(RDKDYNLOG_LIB)
    endif()

    if (NOT TARGET utility::utility)
        add_library(utility::utility INTERFACE IMPORTED)
        set_target_properties(utility::utility PROPERTIES
            INTERFACE_LINK_LIBRARIES "utility::sysutils;utility::miscutils;utility::rfcconfig;utility::curlutils;utility::rdkdynamiclog"
        )
    endif()

    include(FindPackageHandleStandardArgs)
    find_package_handle_standard_args(utility DEFAULT_MSG SYSUTILS_LIB MISCUTILS_LIB RFCCONFIG_LIB CURLUTILS_LIB RDKDYNLOG_LIB)

endif()
