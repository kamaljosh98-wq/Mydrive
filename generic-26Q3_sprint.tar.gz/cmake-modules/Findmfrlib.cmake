##########################################################################
# Findmfrlib.cmake
# 
# Creates individual imported targets for MFR libraries:
#   mfrlib::mfrapi, mfrlib::cgicomm, mfrlib::sccomm
#
# Note: mfrApi is the primary library. cgicomm and sccomm are dependencies.
# Note: ALSA (asound) has its own separate find module (Findalsa.cmake)
##########################################################################

if (NOT MFRLIB_FOUND)

include(ThumbnailCommon)

find_package(PkgConfig)

pkg_check_modules(PC_MFRLIB QUIET mfrlib)

find_path(MFRLIB_INCLUDE_DIRS NAMES mfrApi.h 
    PATHS ${PC_MFRLIB_INCLUDE_DIRS} ${THUMBNAIL_COMMON_INCLUDE_PATHS})
find_library(MFRAPI_LIB NAMES mfrApi 
    PATHS ${PC_MFRLIB_LIBRARY_DIRS} ${THUMBNAIL_COMMON_LIBRARY_PATHS})
find_library(CGICOMM_LIB NAMES cgicomm 
    PATHS ${THUMBNAIL_COMMON_LIBRARY_PATHS})
find_library(SCCOMM_LIB NAMES sccomm 
    PATHS ${THUMBNAIL_COMMON_LIBRARY_PATHS})

# Set deprecated variables
set(MFRLIB_LIBRARY "${MFRAPI_LIB}")
set(MFRLIB_INCLUDE_DIR "${MFRLIB_INCLUDE_DIRS}")

# Build library list for backward compatibility
set(MFRLIB_LIBRARIES)
if(MFRAPI_LIB)
    list(APPEND MFRLIB_LIBRARIES ${MFRAPI_LIB})
endif()
if(CGICOMM_LIB)
    list(APPEND MFRLIB_LIBRARIES ${CGICOMM_LIB})
endif()
if(SCCOMM_LIB)
    list(APPEND MFRLIB_LIBRARIES ${SCCOMM_LIB})
endif()

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(mfrlib DEFAULT_MSG MFRAPI_LIB MFRLIB_INCLUDE_DIRS)

# Create individual imported targets per library (not aggregated)
if (MFRLIB_FOUND)
    # mfrlib::sccomm (serial communication library, depends on mxml)
    if(SCCOMM_LIB AND NOT TARGET mfrlib::sccomm)
        add_library(mfrlib::sccomm UNKNOWN IMPORTED)
        set_target_properties(mfrlib::sccomm PROPERTIES
            IMPORTED_LOCATION "${SCCOMM_LIB}")
        # sccomm depends on mxml (libsccomm.so was built without linking mxml,
        # so we need to provide it when linking executables)
        find_package(mxml QUIET)
        if(TARGET mxml::mxml)
            set_property(TARGET mfrlib::sccomm APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES mxml::mxml)
        endif()
    endif()
    
    # mfrlib::cgicomm (CGI communication library, depends on sccomm and ALSA)
    if(CGICOMM_LIB AND NOT TARGET mfrlib::cgicomm)
        add_library(mfrlib::cgicomm UNKNOWN IMPORTED)
        set_target_properties(mfrlib::cgicomm PROPERTIES
            IMPORTED_LOCATION "${CGICOMM_LIB}")
        # cgicomm depends on sccomm
        if(TARGET mfrlib::sccomm)
            set_property(TARGET mfrlib::cgicomm APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES mfrlib::sccomm)
        endif()
        # cgicomm also depends on ALSA (asound)
        find_package(alsa QUIET)
        if(TARGET alsa::alsa)
            set_property(TARGET mfrlib::cgicomm APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES alsa::alsa)
        endif()
    endif()

    # mfrlib::mfrapi (main MFR API library, depends on cgicomm)
    if(MFRAPI_LIB AND NOT TARGET mfrlib::mfrapi)
        add_library(mfrlib::mfrapi UNKNOWN IMPORTED)
        set_target_properties(mfrlib::mfrapi PROPERTIES
            IMPORTED_LOCATION "${MFRAPI_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_MFRLIB_CFLAGS_OTHER}"
            INTERFACE_COMPILE_DEFINITIONS "USE_MFRLIB")
        if(MFRLIB_INCLUDE_DIRS)
            set_property(TARGET mfrlib::mfrapi PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${MFRLIB_INCLUDE_DIRS}")
        endif()
        # mfrapi depends on cgicomm
        if(TARGET mfrlib::cgicomm)
            set_property(TARGET mfrlib::mfrapi APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES mfrlib::cgicomm)
        endif()
    endif()
endif()

mark_as_advanced(MFRLIB_INCLUDE_DIR MFRLIB_LIBRARY
                 MFRLIB_INCLUDE_DIRS MFRLIB_LIBRARIES
                 MFRAPI_LIB CGICOMM_LIB SCCOMM_LIB)

endif()
