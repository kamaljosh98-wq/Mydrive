##########################################################################
# Findopencv.cmake
# 
# Creates individual imported targets for OpenCV libraries:
#   opencv::core, opencv::imgproc, opencv::imgcodecs, opencv::highgui, 
#   opencv::videoio, opencv::calib3d, opencv::dnn, opencv::features2d,
#   opencv::flann, opencv::ml, opencv::objdetect, opencv::photo, opencv::video
#
# Also provides opencv::opencv aggregated target for backward compatibility.
##########################################################################

if (NOT OPENCV_FOUND)

include(ThumbnailCommon)

find_package(PkgConfig)

# Try pkg-config first
pkg_check_modules(PC_OPENCV QUIET opencv opencv4)

# Find include directories using pkg-config paths
find_path(OPENCV_INCLUDE_DIRS NAMES opencv2/opencv.hpp
    PATHS ${PC_OPENCV_INCLUDE_DIRS} ${THUMBNAIL_COMMON_INCLUDE_PATHS}
    PATH_SUFFIXES "" opencv4)

# Define the core OpenCV library components we want to support
set(_opencv_components 
    core imgproc imgcodecs highgui videoio 
    calib3d dnn features2d flann ml objdetect photo video)

# Find each library individually
set(OPENCV_LIBRARIES "")
foreach(_comp ${_opencv_components})
    find_library(OPENCV_${_comp}_LIBRARY 
        NAMES opencv_${_comp}
        PATHS ${PC_OPENCV_LIBRARY_DIRS} ${THUMBNAIL_COMMON_LIBRARY_PATHS})
    
    if(OPENCV_${_comp}_LIBRARY)
        list(APPEND OPENCV_LIBRARIES ${OPENCV_${_comp}_LIBRARY})
        set(OPENCV_${_comp}_FOUND TRUE)
    else()
        set(OPENCV_${_comp}_FOUND FALSE)
    endif()
endforeach()

# Set deprecated variables
if(OPENCV_LIBRARIES)
    list(GET OPENCV_LIBRARIES 0 OPENCV_LIBRARY)
else()
    set(OPENCV_LIBRARY "")
endif()
set(OPENCV_INCLUDE_DIR "${OPENCV_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(opencv DEFAULT_MSG OPENCV_LIBRARIES OPENCV_INCLUDE_DIRS)

# Create individual imported targets per library (not aggregated)
if (OPENCV_FOUND)
    # opencv::core (base library, no dependencies)
    if(OPENCV_core_FOUND AND NOT TARGET opencv::core)
        add_library(opencv::core UNKNOWN IMPORTED)
        set_target_properties(opencv::core PROPERTIES
            IMPORTED_LOCATION "${OPENCV_core_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}"
            INTERFACE_COMPILE_DEFINITIONS "USE_OPENCV")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::core PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
    endif()
    
    # opencv::imgproc (depends on core)
    if(OPENCV_imgproc_FOUND AND NOT TARGET opencv::imgproc)
        add_library(opencv::imgproc UNKNOWN IMPORTED)
        set_target_properties(opencv::imgproc PROPERTIES
            IMPORTED_LOCATION "${OPENCV_imgproc_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::imgproc PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::imgproc APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
    endif()
    
    # opencv::imgcodecs (depends on core, imgproc)
    if(OPENCV_imgcodecs_FOUND AND NOT TARGET opencv::imgcodecs)
        add_library(opencv::imgcodecs UNKNOWN IMPORTED)
        set_target_properties(opencv::imgcodecs PROPERTIES
            IMPORTED_LOCATION "${OPENCV_imgcodecs_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::imgcodecs PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::imgcodecs APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::imgcodecs APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
    endif()
    
    # opencv::highgui (depends on core, imgproc, imgcodecs)
    if(OPENCV_highgui_FOUND AND NOT TARGET opencv::highgui)
        add_library(opencv::highgui UNKNOWN IMPORTED)
        set_target_properties(opencv::highgui PROPERTIES
            IMPORTED_LOCATION "${OPENCV_highgui_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::highgui PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::highgui APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::highgui APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
        if(TARGET opencv::imgcodecs)
            set_property(TARGET opencv::highgui APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgcodecs)
        endif()
    endif()
    
    # opencv::videoio (depends on core, imgproc, imgcodecs)
    if(OPENCV_videoio_FOUND AND NOT TARGET opencv::videoio)
        add_library(opencv::videoio UNKNOWN IMPORTED)
        set_target_properties(opencv::videoio PROPERTIES
            IMPORTED_LOCATION "${OPENCV_videoio_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::videoio PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::videoio APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::videoio APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
        if(TARGET opencv::imgcodecs)
            set_property(TARGET opencv::videoio APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgcodecs)
        endif()
    endif()
    
    # opencv::calib3d (depends on core, imgproc, features2d, flann)
    if(OPENCV_calib3d_FOUND AND NOT TARGET opencv::calib3d)
        add_library(opencv::calib3d UNKNOWN IMPORTED)
        set_target_properties(opencv::calib3d PROPERTIES
            IMPORTED_LOCATION "${OPENCV_calib3d_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::calib3d PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::calib3d APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::calib3d APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
        if(TARGET opencv::features2d)
            set_property(TARGET opencv::calib3d APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::features2d)
        endif()
        if(TARGET opencv::flann)
            set_property(TARGET opencv::calib3d APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::flann)
        endif()
    endif()
    
    # opencv::dnn (depends on core, imgproc)
    if(OPENCV_dnn_FOUND AND NOT TARGET opencv::dnn)
        add_library(opencv::dnn UNKNOWN IMPORTED)
        set_target_properties(opencv::dnn PROPERTIES
            IMPORTED_LOCATION "${OPENCV_dnn_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::dnn PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::dnn APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::dnn APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
    endif()
    
    # opencv::features2d (depends on core, imgproc, flann)
    if(OPENCV_features2d_FOUND AND NOT TARGET opencv::features2d)
        add_library(opencv::features2d UNKNOWN IMPORTED)
        set_target_properties(opencv::features2d PROPERTIES
            IMPORTED_LOCATION "${OPENCV_features2d_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::features2d PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::features2d APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::features2d APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
        if(TARGET opencv::flann)
            set_property(TARGET opencv::features2d APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::flann)
        endif()
    endif()
    
    # opencv::flann (depends on core)
    if(OPENCV_flann_FOUND AND NOT TARGET opencv::flann)
        add_library(opencv::flann UNKNOWN IMPORTED)
        set_target_properties(opencv::flann PROPERTIES
            IMPORTED_LOCATION "${OPENCV_flann_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::flann PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::flann APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
    endif()
    
    # opencv::ml (depends on core)
    if(OPENCV_ml_FOUND AND NOT TARGET opencv::ml)
        add_library(opencv::ml UNKNOWN IMPORTED)
        set_target_properties(opencv::ml PROPERTIES
            IMPORTED_LOCATION "${OPENCV_ml_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::ml PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::ml APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
    endif()
    
    # opencv::objdetect (depends on core, imgproc, calib3d)
    if(OPENCV_objdetect_FOUND AND NOT TARGET opencv::objdetect)
        add_library(opencv::objdetect UNKNOWN IMPORTED)
        set_target_properties(opencv::objdetect PROPERTIES
            IMPORTED_LOCATION "${OPENCV_objdetect_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::objdetect PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::objdetect APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::objdetect APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
        if(TARGET opencv::calib3d)
            set_property(TARGET opencv::objdetect APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::calib3d)
        endif()
    endif()
    
    # opencv::photo (depends on core, imgproc)
    if(OPENCV_photo_FOUND AND NOT TARGET opencv::photo)
        add_library(opencv::photo UNKNOWN IMPORTED)
        set_target_properties(opencv::photo PROPERTIES
            IMPORTED_LOCATION "${OPENCV_photo_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::photo PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::photo APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::photo APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
    endif()
    
    # opencv::video (depends on core, imgproc)
    if(OPENCV_video_FOUND AND NOT TARGET opencv::video)
        add_library(opencv::video UNKNOWN IMPORTED)
        set_target_properties(opencv::video PROPERTIES
            IMPORTED_LOCATION "${OPENCV_video_LIBRARY}"
            INTERFACE_COMPILE_OPTIONS "${PC_OPENCV_CFLAGS_OTHER}")
        if(OPENCV_INCLUDE_DIRS)
            set_property(TARGET opencv::video PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${OPENCV_INCLUDE_DIRS}")
        endif()
        if(TARGET opencv::core)
            set_property(TARGET opencv::video APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::core)
        endif()
        if(TARGET opencv::imgproc)
            set_property(TARGET opencv::video APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES opencv::imgproc)
        endif()
    endif()
    
    # Legacy aggregated target for backward compatibility
    # Links all found OpenCV libraries
    if(NOT TARGET opencv::opencv)
        add_library(opencv::opencv INTERFACE IMPORTED)
        set(_opencv_link_libs "")
        foreach(_comp ${_opencv_components})
            if(TARGET opencv::${_comp})
                list(APPEND _opencv_link_libs opencv::${_comp})
            endif()
        endforeach()
        if(_opencv_link_libs)
            set_property(TARGET opencv::opencv PROPERTY
                INTERFACE_LINK_LIBRARIES ${_opencv_link_libs})
        endif()
    endif()
endif()

mark_as_advanced(OPENCV_INCLUDE_DIR OPENCV_LIBRARY OPENCV_INCLUDE_DIRS OPENCV_LIBRARIES)
# Mark individual component variables as advanced
foreach(_comp ${_opencv_components})
    mark_as_advanced(OPENCV_${_comp}_LIBRARY OPENCV_${_comp}_FOUND)
endforeach()

endif()
