if (NOT STREAMER_FOUND)
    if(DEFINED STAGING_DIR_TARGET OR DEFINED RDK_FSROOT_PATH)
        include(RDKPaths)
    endif()
    if(DEFINED YOCTO_SYSROOT OR DEFINED RDK_FSROOT_PATH)
        include(RDKPaths)
    endif()
    find_package(PkgConfig)
    if (PKG_CONFIG_FOUND)
        pkg_check_modules(STREAMER_PC QUIET streamer)
    endif()

    find_path(STREAMER_INCLUDE_DIRS NAMES xStreamerConsumer.h HINTS ${STREAMER_PC_INCLUDE_DIRS} PATH_SUFFIXES streamer)
    find_path(STREAMER_IOCTL_INCLUDE_DIRS NAMES iav_ioctl.h HINTS ${STREAMER_PC_INCLUDE_DIRS} PATHS ${AMBA_INCLUDE_DIR} PATH_SUFFIXES ${SOC_VERSION})

    message(STATUS "Findstreamer: LIB_PATH = ${LIB_PATH}")
    message(STATUS "Findstreamer: SHADOW_ROOT_LIB_PATH = ${SHADOW_ROOT_LIB_PATH}")

    # Try to find streamer libraries first via pkg-config paths
    find_library(STREAMERPRODUCER_LIB NAMES streamerproducer HINTS ${STREAMER_PC_LIBRARY_DIRS})
    # If not found, try SDK paths
    if(NOT STREAMERPRODUCER_LIB)
        find_library(STREAMERPRODUCER_LIB NAMES streamerproducer HINTS ${LIB_PATH} ${SHADOW_ROOT_LIB_PATH})
    endif()
    # Final fallback: search system paths
    if(NOT STREAMERPRODUCER_LIB)
        find_library(STREAMERPRODUCER_LIB NAMES streamerproducer)
    endif()

    if (STREAMERPRODUCER_LIB AND NOT TARGET streamer::streamerproducer)
        set(include_dirs "${STREAMER_INCLUDE_DIRS}")
        if(STREAMER_IOCTL_INCLUDE_DIRS)
            list(APPEND include_dirs "${STREAMER_IOCTL_INCLUDE_DIRS}")
        endif()
        add_library(streamer::streamerproducer UNKNOWN IMPORTED)
        set_target_properties(streamer::streamerproducer PROPERTIES
            IMPORTED_LOCATION "${STREAMERPRODUCER_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${include_dirs}"
            INTERFACE_COMPILE_OPTIONS "${STREAMER_PC_CFLAGS_OTHER}"
        )
        mark_as_advanced(STREAMERPRODUCER_LIB)
    endif()

    find_library(STREAMERCONSUMER_LIB NAMES streamerconsumer HINTS ${STREAMER_PC_LIBRARY_DIRS})
    # If not found, try SDK paths
    if(NOT STREAMERCONSUMER_LIB)
        find_library(STREAMERCONSUMER_LIB NAMES streamerconsumer HINTS ${LIB_PATH} ${SHADOW_ROOT_LIB_PATH})
    endif()
    # Final fallback: search system paths
    if(NOT STREAMERCONSUMER_LIB)
        find_library(STREAMERCONSUMER_LIB NAMES streamerconsumer)
    endif()

    if (STREAMERCONSUMER_LIB AND NOT TARGET streamer::streamerconsumer)
        set(include_dirs "${STREAMER_INCLUDE_DIRS}")
        if(STREAMER_IOCTL_INCLUDE_DIRS)
            list(APPEND include_dirs "${STREAMER_IOCTL_INCLUDE_DIRS}")
        endif()
        add_library(streamer::streamerconsumer UNKNOWN IMPORTED)
        set_target_properties(streamer::streamerconsumer PROPERTIES
            IMPORTED_LOCATION "${STREAMERCONSUMER_LIB}"
            INTERFACE_INCLUDE_DIRECTORIES "${include_dirs}"
            INTERFACE_COMPILE_OPTIONS "${STREAMER_PC_CFLAGS_OTHER}"
        )
        mark_as_advanced(STREAMERCONSUMER_LIB)
    endif()

    if (NOT TARGET streamer::streamer)
        add_library(streamer::streamer INTERFACE IMPORTED)
        set_target_properties(streamer::streamer PROPERTIES
            INTERFACE_LINK_LIBRARIES "streamer::streamerproducer;streamer::streamerconsumer"
        )
    endif()

    include(FindPackageHandleStandardArgs)
    find_package_handle_standard_args(streamer DEFAULT_MSG STREAMERPRODUCER_LIB STREAMERCONSUMER_LIB)

endif()
