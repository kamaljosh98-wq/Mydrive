##########################################################################
# Findlog4c.cmake
#
# Find log4c logging library.
# Creates imported target: log4c::log4c
##########################################################################

if (NOT LOG4C_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_LOG4C QUIET log4c)

find_path(LOG4C_INCLUDE_DIRS NAMES log4c.h PATHS ${PC_LOG4C_INCLUDE_DIRS})
find_library(LOG4C_LIBRARIES NAMES log4c PATHS ${PC_LOG4C_LIBRARY_DIRS})

# Set deprecated variables
set(LOG4C_LIBRARY "${LOG4C_LIBRARIES}")
set(LOG4C_INCLUDE_DIR "${LOG4C_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(log4c DEFAULT_MSG LOG4C_LIBRARIES LOG4C_INCLUDE_DIRS)

if (LOG4C_FOUND AND NOT TARGET log4c::log4c)
    add_library(log4c::log4c UNKNOWN IMPORTED)
    set_target_properties(log4c::log4c PROPERTIES
                          IMPORTED_LOCATION "${LOG4C_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_LOG4C_CFLAGS_OTHER}"
                          INTERFACE_INCLUDE_DIRECTORIES "${LOG4C_INCLUDE_DIRS}")
endif()

mark_as_advanced(LOG4C_INCLUDE_DIR LOG4C_LIBRARY
                 LOG4C_INCLUDE_DIRS LOG4C_LIBRARIES)

endif()
