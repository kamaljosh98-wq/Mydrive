# ThumbnailCommon.cmake - Common configuration for thumbnail project
#
# This file centralizes paths and valuable helper functions.
#
# PUBLIC API:
#   - THUMBNAIL_COMMON_INCLUDE_PATHS   - Common include search paths
#   - THUMBNAIL_COMMON_LIBRARY_PATHS   - Common library search paths
#   - setup_thumbnail_base()           - Setup base compiler flags and includes
#   - link_common_deps()               - Link common dependencies
#   - setup_consumer_plugin_includes() - Setup XStreamer includes
#   - link_consumer_plugin_libs()      - Link consumer/plugin libs
#   - ensure_miscutils()               - Find and link miscutils if needed
#   - force_link_mxml_if_configmgr()   - Fix ConfigMgr MXML deps

# Ensure required variables are set
if(NOT DEFINED RDK_PROJECT_ROOT_PATH)
    message(FATAL_ERROR "RDK_PROJECT_ROOT_PATH is not defined")
endif()

if(NOT DEFINED XCAM_MODEL)
    message(WARNING "XCAM_MODEL not defined, defaulting to XHC3")
    set(XCAM_MODEL "XHC3")
endif()

# Yocto builds: Find arch-specific headers at configure time
# These headers are required by stream_hal_api.h but may not be in standard sysroot paths
# XHB1/DBC uses arch_s5l, XHC3 uses arch_s2l
if(IS_YOCTO_BUILD)
    if(XCAM_MODEL STREQUAL "XHB1")
        set(AMBA_ARCH_SUBDIR "arch_s5l")
        set(HEADER_TO_FIND "iav_ioctl.h")
    elseif(XCAM_MODEL STREQUAL "XHC3")
        set(AMBA_ARCH_SUBDIR "arch_s2l")
        set(HEADER_TO_FIND "iav_types_arch.h")
    endif()

    if(DEFINED AMBA_ARCH_SUBDIR)
        find_path(IAV_ARCH_INCLUDE_DIR
            NAMES ${HEADER_TO_FIND}
            PATHS
                ${CMAKE_SYSROOT}/usr/include/${AMBA_ARCH_SUBDIR}
                ${CMAKE_SYSROOT}/usr/include/amba/include/${AMBA_ARCH_SUBDIR}
                ${CMAKE_SYSROOT}/sdk/fsroot/src/amba/include/${AMBA_ARCH_SUBDIR}
                ${CMAKE_SYSROOT}/usr/include
                ${CMAKE_SYSROOT}/opensource/include
            NO_DEFAULT_PATH
        )

        if(IAV_ARCH_INCLUDE_DIR)
            message(STATUS "ThumbnailCommon: Found ${HEADER_TO_FIND} in: ${IAV_ARCH_INCLUDE_DIR}")
            include_directories(${IAV_ARCH_INCLUDE_DIR})
        else()
            message(WARNING "ThumbnailCommon: ${HEADER_TO_FIND} not found in ${XCAM_MODEL} sysroot - compilation will fail")
            message(WARNING "  CMAKE_SYSROOT: ${CMAKE_SYSROOT}")
            message(WARNING "  Expected at: ${CMAKE_SYSROOT}/usr/include/${AMBA_ARCH_SUBDIR}/${HEADER_TO_FIND}")
        endif()
    endif()
endif()

# Set the main model path (used for XStreamer consumer/plugin includes)
set(XCAM_MODEL_PATH "${RDK_PROJECT_ROOT_PATH}")

# NOTE: LIB_PATH, SHADOW_ROOT_LIB_PATH, AMBA_DIR_PATH, and AMBA_ARCH
# are set by ThumbnailPaths.cmake and should not be redefined here.
# This ensures consistent paths across all CMake modules.

# Common search paths for Find modules
# We only add platform-specific paths that aren't in standard locations.
set(THUMBNAIL_COMMON_INCLUDE_PATHS
    ${XCAM_MODEL_PATH}/opensource/include
)

set(THUMBNAIL_COMMON_LIBRARY_PATHS
    ${XCAM_MODEL_PATH}/opensource/lib
)

# List of all library search paths for find_library() calls
# Only populated for non-Yocto builds
if(NOT IS_YOCTO_BUILD AND LIB_PATH AND AMBA_DIR_PATH)
    set(LIB_SEARCH_PATHS
        ${LIB_PATH}
        ${SHADOW_ROOT_LIB_PATH}
        ${AMBA_DIR_PATH}/prebuild/third-party/armv8-a/alsa-lib/usr/lib
        ${AMBA_DIR_PATH}/prebuild/third-party/armv8-a/mxml/usr/lib
        ${AMBA_DIR_PATH}/prebuild/ambarella/library/dewarp/lib/${AMBA_ARCH}
    )
else()
    set(LIB_SEARCH_PATHS "")
endif()

message(STATUS "ThumbnailCommon: XCAM_MODEL = ${XCAM_MODEL}")
message(STATUS "ThumbnailCommon: XCAM_MODEL_PATH = ${XCAM_MODEL_PATH}")
message(STATUS "ThumbnailCommon: LIB_PATH = ${LIB_PATH}")
message(STATUS "ThumbnailCommon: SHADOW_ROOT_LIB_PATH = ${SHADOW_ROOT_LIB_PATH}")

# Unified MiscUtils handling
function(ensure_miscutils TARGET_NAME)
    if(NOT TARGET ${TARGET_NAME})
        message(FATAL_ERROR "ensure_miscutils: Target '${TARGET_NAME}' does not exist")
    endif()

    # Determine requirement (guard against undefined vars)
    set(need_ FALSE)
    if((DEFINED USE_FILEUTILS AND USE_FILEUTILS) OR
       (DEFINED USE_MISC AND USE_MISC) OR
       (DEFINED ENABLE_DELIVERY_DETECTION AND ENABLE_DELIVERY_DETECTION) OR
       (DEFINED OSI))
        set(need_ TRUE)
    endif()

    if(need_)
        if(NOT TARGET miscutils::miscutils)
            find_package(miscutils REQUIRED)
        endif()
        target_link_libraries(${TARGET_NAME} PRIVATE miscutils::miscutils)
        message(STATUS "ensure_miscutils: Linked MiscUtils to ${TARGET_NAME}")
    endif()
endfunction()

# Common function for setting up base configuration
function(setup_thumbnail_base TARGET_NAME)
    if(NOT TARGET ${TARGET_NAME})
        message(FATAL_ERROR "setup_thumbnail_base: Target '${TARGET_NAME}' does not exist")
    endif()

    # Standard compiler settings
    target_compile_options(${TARGET_NAME} PRIVATE
        -fstack-protector -Wno-error -g -Wall -Wextra -fPIC
    )

    # Standard target properties
    set_target_properties(${TARGET_NAME} PROPERTIES
        CXX_STANDARD 14
        CXX_STANDARD_REQUIRED ON
        CXX_EXTENSIONS OFF
        POSITION_INDEPENDENT_CODE ON
    )

    # Base includes that all targets need
    target_include_directories(${TARGET_NAME} PRIVATE
        ${XCAM_MODEL_PATH}/opensource/include
    )

    # Model-specific definitions
    if(XCAM_MODEL STREQUAL "SCHC2")
        target_compile_definitions(${TARGET_NAME} PRIVATE -DXCAM2)
    elseif(XCAM_MODEL STREQUAL "XHB1")
        target_compile_definitions(${TARGET_NAME} PRIVATE -DXHB1)
    elseif(XCAM_MODEL STREQUAL "XHC3")
        target_compile_definitions(${TARGET_NAME} PRIVATE -DXHC3)
    endif()
endfunction()

# Function for linking common dependencies
function(link_common_deps TARGET_NAME)
    target_link_libraries(${TARGET_NAME} PRIVATE
        rdklogger::rdklogger
        rtmessage::rtmessage
        Threads::Threads
    )

    # Verify critical library paths exist before linking
    if(LIB_PATH AND NOT IS_YOCTO_BUILD)
        set(required_libs_ ssl crypto jansson trower-base64 httpclient configmanager sysutils mfrApi sccomm cgicomm asound)

        foreach(lib_ ${required_libs_})
            if(NOT EXISTS "${LIB_PATH}/lib${lib_}.so")
                message(FATAL_ERROR "Required library not found: ${LIB_PATH}/lib${lib_}.so - Check RDK_PROJECT_ROOT_PATH and build dependencies")
            endif()
        endforeach()
    endif()

    # Base libraries - use full paths for non-Yocto builds (no pkg-config)
    if(NOT IS_YOCTO_BUILD AND LIB_PATH)
        target_link_libraries(${TARGET_NAME} PRIVATE
            ${LIB_PATH}/libssl.so
            ${LIB_PATH}/libcrypto.so
            ${LIB_PATH}/libjansson.so
            ${LIB_PATH}/libtrower-base64.so
            ${LIB_PATH}/libhttpclient.so
            ${LIB_PATH}/libconfigmanager.so
            ${LIB_PATH}/libsysutils.so
            ${LIB_PATH}/libmfrApi.so
            ${LIB_PATH}/libsccomm.so
            ${LIB_PATH}/libcgicomm.so
            ${LIB_PATH}/libasound.so
        )
    elseif(IS_YOCTO_BUILD)
        # Let pkg-config find them
        target_link_libraries(${TARGET_NAME} PRIVATE
            ssl crypto jansson trower-base64
            httpclient configmanager sysutils mfrApi sccomm cgicomm asound
            log4c
        )
    endif()
endfunction()

# Function to setup consumer/plugin includes based on configuration
function(setup_consumer_plugin_includes TARGET_NAME)
    if(USE_CONSUMER)
        # Note: AMBA_DIR_PATH and AMBA_ARCH are set by ThumbnailPaths.cmake

        target_include_directories(${TARGET_NAME} PRIVATE
            ${RDK_PROJECT_ROOT_PATH}/usr/include
            ${RDK_PROJECT_ROOT_PATH}/usr/include/streamer
            ${RDK_PROJECT_ROOT_PATH}/camera-hal/streamer/xBroker
            ${RDK_PROJECT_ROOT_PATH}/camera-hal/streamer/xBroker/xConsumer
            ${RDK_PROJECT_ROOT_PATH}/camera-hal/streamer
            ${RDK_PROJECT_ROOT_PATH}/sysapps/apps/cgi/cgi
            ${RDK_PROJECT_ROOT_PATH}/sysapps/apps/cgi/cgilib
            ${RDK_PROJECT_ROOT_PATH}/sysapps/apps/cgi/libcgicomm/inc
            ${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/share/sc_config
            ${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/src/share/libsccomm/inc
            ${AMBA_DIR_PATH}
            ${AMBA_DIR_PATH}/include
        )

        # Model-specific architecture includes (using AMBA_ARCH from ThumbnailPaths.cmake)
        if(AMBA_DIR_PATH AND AMBA_ARCH)
            target_include_directories(${TARGET_NAME} PRIVATE
                ${AMBA_DIR_PATH}/include/${AMBA_ARCH}
            )
        endif()
    endif()

    if(USE_PLUGINS)
        target_include_directories(${TARGET_NAME} PRIVATE
            ${RDK_PROJECT_ROOT_PATH}/plugins
            ${RDK_PROJECT_ROOT_PATH}/plugins/soc
        )
    endif()
endfunction()

# Function to link consumer/plugin libraries
function(link_consumer_plugin_libs TARGET_NAME)
    if(USE_CONSUMER)
        # Link libstreamerconsumer.so and its dependencies for XStreamerConsumer functionality
        # Strategy: Check IS_YOCTO_BUILD first, not file existence
        # - Yocto builds: Use library names, let toolchain find in sysroot
        # - Non-Yocto builds: Use explicit paths from camera-hal build directory

        if(IS_YOCTO_BUILD)
            # Yocto: Libraries are in sysroot, use names only
            target_link_libraries(${TARGET_NAME} PRIVATE
                streamerconsumer
                streamerhal
                dewarp
                utils
            )
            message(STATUS "link_consumer_plugin_libs: Linked XStreamer libraries for ${TARGET_NAME} (Yocto mode)")
        else()
            # Non-Yocto: Use library search paths similar to original Makefile approach
            # The original AppsRule.mak only explicitly linked libstreamerconsumer from shadow_root,
            # and let the linker find dependencies (streamerhal, dewarp, utils) via rpath/library paths

            # Add shadow_root library directory for streamerconsumer (matches original Makefile)
            if(SHADOW_ROOT_LIB_PATH AND EXISTS "${SHADOW_ROOT_LIB_PATH}")
                link_directories(${SHADOW_ROOT_LIB_PATH})
            endif()

            # Link only the primary libraries by name, let linker resolve dependencies
            # This matches the original Makefile behavior which only linked -lstreamerconsumer
            target_link_libraries(${TARGET_NAME} PRIVATE
                streamerconsumer
                streamerhal
                dewarp
                utils
            )
            message(STATUS "link_consumer_plugin_libs: Linked XStreamer libraries for ${TARGET_NAME} (non-Yocto mode)")
            message(STATUS "  Using library search paths (original Makefile style)")
        endif()
    endif()

    if(USE_PLUGINS)
        target_link_libraries(${TARGET_NAME} PRIVATE halrtc)
    endif()

    # XHC3 specific libraries
    if(XCAM_MODEL STREQUAL "XHC3")
        target_link_libraries(${TARGET_NAME} PRIVATE rfcconfig)
    endif()
endfunction()

# Force link MXML for targets that use ConfigMgr
function(force_link_mxml_if_configmgr TARGET_NAME USES_CONFIGMGR)
    if(${USES_CONFIGMGR})
        find_library(MXML_LIBRARY_DIRECT
            NAMES mxml
            PATHS ${THUMBNAIL_COMMON_LIBRARY_PATHS}
            NO_DEFAULT_PATH
        )
        if(MXML_LIBRARY_DIRECT)
            target_link_libraries(${TARGET_NAME} PRIVATE ${MXML_LIBRARY_DIRECT})
            message(STATUS "CRITICAL FIX: Force linked libmxml.so to ${TARGET_NAME}")
        else()
            message(WARNING "CRITICAL FIX: Could not find libmxml.so for ${TARGET_NAME}")
        endif()
    endif()
endfunction()
