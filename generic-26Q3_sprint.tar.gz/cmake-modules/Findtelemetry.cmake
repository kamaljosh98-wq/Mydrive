##########################################################################
# Findtelemetry.cmake
# 
# Creates individual imported targets for telemetry libraries:
#   telemetry::msgsender, telemetry::t2utils
#
# Also provides telemetry::telemetry aggregated target for backward compatibility.
# Note: msgpackc has its own separate find module (Findmsgpackc.cmake)
##########################################################################

if (NOT TELEMETRY_FOUND)

find_package(PkgConfig)

pkg_check_modules(PC_TELEMETRY QUIET telemetry)

# Manual search paths for non-Yocto builds
set(_TELEMETRY_SEARCH_PATHS
    ${PC_TELEMETRY_INCLUDE_DIRS}
    ${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/ramdisk/usr/include
    ${RDK_PROJECT_ROOT_PATH}/telemetry/include
)

set(_TELEMETRY_LIB_SEARCH_PATHS
    ${PC_TELEMETRY_LIBRARY_DIRS}
    ${RDK_PROJECT_ROOT_PATH}/sdk/fsroot/ramdisk/usr/lib
)

find_path(TELEMETRY_INCLUDE_DIRS NAMES telemetry_busmessage_sender.h PATHS ${_TELEMETRY_SEARCH_PATHS})
find_library(TELEMETRY_MSGSENDER_LIB NAMES telemetry_msgsender PATHS ${_TELEMETRY_LIB_SEARCH_PATHS})
find_library(T2UTILS_LIB NAMES t2utils PATHS ${_TELEMETRY_LIB_SEARCH_PATHS})

# Build library list for compatibility
set(TELEMETRY_LIBRARIES)
if(TELEMETRY_MSGSENDER_LIB)
    list(APPEND TELEMETRY_LIBRARIES ${TELEMETRY_MSGSENDER_LIB})
endif()
if(T2UTILS_LIB)
    list(APPEND TELEMETRY_LIBRARIES ${T2UTILS_LIB})
endif()

# Set deprecated variables
set(TELEMETRY_LIBRARY "${TELEMETRY_MSGSENDER_LIB}")
set(TELEMETRY_INCLUDE_DIR "${TELEMETRY_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
find_package_handle_standard_args(telemetry DEFAULT_MSG TELEMETRY_MSGSENDER_LIB TELEMETRY_INCLUDE_DIRS)

# Create individual imported targets per library (not aggregated)
if (TELEMETRY_FOUND)
    # telemetry::msgsender (main telemetry message sender library)
    if(TELEMETRY_MSGSENDER_LIB AND NOT TARGET telemetry::msgsender)
        add_library(telemetry::msgsender UNKNOWN IMPORTED)
        set_target_properties(telemetry::msgsender PROPERTIES
            IMPORTED_LOCATION "${TELEMETRY_MSGSENDER_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_TELEMETRY_CFLAGS_OTHER}")
        if(TELEMETRY_INCLUDE_DIRS)
            set_property(TARGET telemetry::msgsender PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${TELEMETRY_INCLUDE_DIRS}")
        endif()
        # msgsender depends on msgpackc
        find_package(msgpackc QUIET)
        if(TARGET msgpackc::msgpackc)
            set_property(TARGET telemetry::msgsender APPEND PROPERTY
                INTERFACE_LINK_LIBRARIES msgpackc::msgpackc)
        endif()
    endif()
    
    # telemetry::t2utils (telemetry utilities library)
    if(T2UTILS_LIB AND NOT TARGET telemetry::t2utils)
        add_library(telemetry::t2utils UNKNOWN IMPORTED)
        set_target_properties(telemetry::t2utils PROPERTIES
            IMPORTED_LOCATION "${T2UTILS_LIB}"
            INTERFACE_COMPILE_OPTIONS "${PC_TELEMETRY_CFLAGS_OTHER}")
        if(TELEMETRY_INCLUDE_DIRS)
            set_property(TARGET telemetry::t2utils PROPERTY
                INTERFACE_INCLUDE_DIRECTORIES "${TELEMETRY_INCLUDE_DIRS}")
        endif()
    endif()
    
    # Legacy aggregated target for backward compatibility
    if(NOT TARGET telemetry::telemetry)
        add_library(telemetry::telemetry INTERFACE IMPORTED)
        set(_telemetry_link_libs "")
        if(TARGET telemetry::msgsender)
            list(APPEND _telemetry_link_libs telemetry::msgsender)
        endif()
        if(TARGET telemetry::t2utils)
            list(APPEND _telemetry_link_libs telemetry::t2utils)
        endif()
        # Add libsecure_wrapper dependency (required by telemetry at runtime)
        find_package(libsyswrapper QUIET)
        if(TARGET libsyswrapper::libsyswrapper)
            list(APPEND _telemetry_link_libs libsyswrapper::libsyswrapper)
        else()
            message(WARNING "Findtelemetry: libsyswrapper NOT found - telemetry will have missing symbols (t2_init, t2_event_s, t2_event_d)")
        endif()
        if(_telemetry_link_libs)
            set_property(TARGET telemetry::telemetry PROPERTY
                INTERFACE_LINK_LIBRARIES ${_telemetry_link_libs})
        endif()
    endif()
endif()

mark_as_advanced(TELEMETRY_INCLUDE_DIR TELEMETRY_LIBRARY
                 TELEMETRY_INCLUDE_DIRS TELEMETRY_LIBRARIES
                 TELEMETRY_MSGSENDER_LIB T2UTILS_LIB)

endif()
