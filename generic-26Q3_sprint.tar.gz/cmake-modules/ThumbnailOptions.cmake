##########################################################################
# ThumbnailOptions.cmake
#
# Centralized option definitions and feature configuration for the 
# thumbnail-camera project. This file defines all build options and
# their interdependencies in one place for better maintainability.
#
# PUBLIC API:
#   - print_thumbnail_config()  - Print build configuration summary
#
# OPTIONS DEFINED:
#   - ENABLE_XSTREAMER, ENABLE_DELIVERY_DETECTION, ENABLE_TEST_HARNESS
#   - ENABLE_DIRECT_FRAME_READ, USE_FILEUTILS, USE_LEGACY_CONFIG_MGR
#   - THUMBNAIL_DEBUG_FIND_MODULES, THUMBNAIL_EXPERIMENTAL_FFMPEG_DETECTION
#
# DERIVED VARIABLES:
#   - USE_CONSUMER, USE_PLUGINS (based on ENABLE_XSTREAMER)
#   - USE_DEWARP, SUPPORT_MXML (based on XCAM_MODEL)
#   - USE_MISC, NEED_BASE64 (based on ENABLE_DELIVERY_DETECTION)
#
# REMOVED (Obsolete):
#   - THUMBNAIL_COMPONENT_FEATURES matrix - Never used
#   - component_needs_feature() function - Never called
##########################################################################

# Include guard for CMake 3.8 compatibility
if(THUMBNAIL_OPTIONS_INCLUDED)
    return()
endif()
set(THUMBNAIL_OPTIONS_INCLUDED TRUE)

# Include required CMake modules
include(CMakeDependentOption)

# ======================================================
# Build Options - User Configurable
# ======================================================

option(ENABLE_XSTREAMER "Enable XStreamer consumer support" ON)
option(ENABLE_DELIVERY_DETECTION "Enable delivery detection features" OFF)
option(ENABLE_TEST_HARNESS "Build test harness variants" OFF)
option(ENABLE_DIRECT_FRAME_READ "Enable direct frame reading" ON)

# Explicit FileUtils flag decoupled from USE_MISC
option(USE_FILEUTILS "Link miscutils (FileUtils symbols) regardless of USE_MISC" ON)

# Advanced options
cmake_dependent_option(USE_LEGACY_CONFIG_MGR
    "Use legacy configuration manager APIs" OFF
    "USE_CONFIGMGR" OFF)

cmake_dependent_option(THUMBNAIL_DEBUG_FIND_MODULES
    "Enable debug output for Find modules" OFF
    "CMAKE_BUILD_TYPE STREQUAL Debug" OFF)

# ======================================================
# Feature Dependencies and Validation
# ======================================================

# ENABLE_DIRECT_FRAME_READ requires ENABLE_XSTREAMER
if(ENABLE_DIRECT_FRAME_READ AND NOT ENABLE_XSTREAMER)
    message(WARNING "ENABLE_DIRECT_FRAME_READ requires ENABLE_XSTREAMER, enabling XStreamer")
    set(ENABLE_XSTREAMER ON CACHE BOOL "Enable XStreamer consumer support" FORCE)
endif()

# Set consumer/plugin mode based on XStreamer
if(ENABLE_XSTREAMER)
    set(USE_CONSUMER ON)
    set(USE_PLUGINS OFF)
else()
    set(USE_CONSUMER OFF) 
    set(USE_PLUGINS ON)
endif()

# Delivery detection additional dependencies
if(ENABLE_DELIVERY_DETECTION)
    set(USE_MISC ON)
    set(NEED_BASE64 ON)
else()
    set(USE_MISC OFF)
    set(NEED_BASE64 OFF)
endif()

# If delivery detection implies FileUtils usage but USE_FILEUTILS was turned OFF manually, warn
if(ENABLE_DELIVERY_DETECTION AND NOT USE_FILEUTILS)
    message(WARNING "Delivery detection enabled but USE_FILEUTILS=OFF; FileUtils symbols may be missing")
endif()

# ======================================================
# Model-Specific Configuration
# ======================================================

# Validate XCAM_MODEL
set(SUPPORTED_MODELS "XHB1;XHC3;SCHC2")
if(NOT XCAM_MODEL IN_LIST SUPPORTED_MODELS)
    message(WARNING "Unknown XCAM_MODEL '${XCAM_MODEL}', defaulting to XHC3")
    set(XCAM_MODEL "XHC3")
endif()

# Model-specific feature enablement
if(XCAM_MODEL MATCHES "XHB1|XHC3|SCHC2")
    set(USE_DEWARP ON)
else()
    set(USE_DEWARP OFF)
endif()

if(NOT XCAM_MODEL MATCHES "XHB1|XHC3")
    set(SUPPORT_MXML ON)
else()
    set(SUPPORT_MXML OFF)
endif()

# ======================================================
# Configuration Summary Function
# ======================================================

function(print_thumbnail_config)
    message(STATUS "=== Thumbnail Camera Configuration ===")
    message(STATUS "  XCAM Model: ${XCAM_MODEL}")
    message(STATUS "  XStreamer: ${ENABLE_XSTREAMER}")
    message(STATUS "  Consumer Mode: ${USE_CONSUMER}")
    message(STATUS "  Plugin Mode: ${USE_PLUGINS}")
    message(STATUS "  Direct Frame Read: ${ENABLE_DIRECT_FRAME_READ}")
    message(STATUS "  Delivery Detection: ${ENABLE_DELIVERY_DETECTION}")
    message(STATUS "  Test Harness: ${ENABLE_TEST_HARNESS}")
    message(STATUS "  Dewarp Support: ${USE_DEWARP}")
    message(STATUS "  MXML Support: ${SUPPORT_MXML}")
    message(STATUS "  FileUtils (miscutils): ${USE_FILEUTILS}")
    message(STATUS "=======================================")
endfunction()
