##########################################################################
# Findmxml.cmake
#
# Find Mini-XML parsing library.
# Creates imported target: mxml::mxml
##########################################################################

if (NOT MXML_FOUND)

include(ThumbnailCommon)

find_package(PkgConfig)

pkg_check_modules(PC_MXML QUIET mxml)

find_path(MXML_INCLUDE_DIRS NAMES mxml.h 
    PATHS ${PC_MXML_INCLUDE_DIRS} ${THUMBNAIL_COMMON_INCLUDE_PATHS})
find_library(MXML_LIBRARIES NAMES mxml 
    PATHS ${PC_MXML_LIBRARY_DIRS} ${THUMBNAIL_COMMON_LIBRARY_PATHS})

# Set deprecated variables
set(MXML_LIBRARY "${MXML_LIBRARIES}")
set(MXML_INCLUDE_DIR "${MXML_INCLUDE_DIRS}")

include(FindPackageHandleStandardArgs)
# Only require library, not headers (mxml headers are in non-standard nested path)
find_package_handle_standard_args(mxml DEFAULT_MSG MXML_LIBRARIES)

if (MXML_FOUND AND NOT TARGET mxml::mxml)
    add_library(mxml::mxml UNKNOWN IMPORTED)
    set_target_properties(mxml::mxml PROPERTIES
                          IMPORTED_LOCATION "${MXML_LIBRARIES}"
                          INTERFACE_COMPILE_OPTIONS "${PC_MXML_CFLAGS_OTHER}")
    # Only set include directories if found
    if(MXML_INCLUDE_DIRS)
        set_property(TARGET mxml::mxml PROPERTY
            INTERFACE_INCLUDE_DIRECTORIES "${MXML_INCLUDE_DIRS}")
    endif()
endif()

mark_as_advanced(MXML_INCLUDE_DIR MXML_LIBRARY
                 MXML_INCLUDE_DIRS MXML_LIBRARIES)

endif()
