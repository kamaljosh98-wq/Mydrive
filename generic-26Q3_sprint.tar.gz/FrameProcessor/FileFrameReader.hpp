#ifndef FILEFRAMEREADER_HPP
#define FILEFRAMEREADER_HPP

#include "FrameReader.hpp"

class FileFrameReader : public FrameReader
{
public:
    FileFrameReader(const std::string &filePath);
    ~FileFrameReader() override;
    uint64_t readFrame(uint8_t *buffer) override;
    int getWidth() const override;
    int getHeight() const override;

private:
    int mWidth;
    int mHeight;
    cv::VideoCapture mCap;
};

#endif // FILEFRAMEREADER_HPP
