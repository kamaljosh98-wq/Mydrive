#include "YUVFrameReader.hpp"
namespace camera
{
    namespace camera_ml
    {
        /**
         * @brief Constructs a YUVFrameReader object with the specified buffer ID.
         *
         * @param bufferId The ID of the buffer.
         */
        YUVFrameReader::YUVFrameReader(u16 bufferId) : mBufferId(bufferId)
        {
            mRawFrame = std::make_pair(nullptr, nullptr);
            mConsumer = std::make_unique<XStreamerConsumer>();
            if (!mConsumer)
            {
                LOG_ERROR("Error:creating instance of xstreamerConsumer.");
                throw std::runtime_error("Error: creating instance of xstreamerConsumer.");
            }
            if (0 != mConsumer->RAWInit(bufferId))
            {
                LOG_ERROR("Failed to initialize resources for reading raw frames.");
                return;
            }
            mFrameContainer = mConsumer->GetRAWFrameContainer();
            if (!mFrameContainer)
            {
                LOG_ERROR("Failed to create applicaton buffer");
                return;
            }
            mConsumer->GetSourceBufferResolution(bufferId, mWidth, mHeight);
            LOG_INFO("Frame width: " << mWidth << ", height: " << mHeight);
        }

        /**
         * Reads a frame from the YUVFrameReader.
         *
         * @param buffer The buffer to store the frame data.
         * @return True if the frame was successfully read, false otherwise.
         */
        uint64_t YUVFrameReader::readFrame(uint8_t *buffer)
        {
            if (!buffer)
            {
                LOG_ERROR("Error: Null buffer provided to readFrame.");
                return -1;
            }
            size_t y_size = mWidth * mHeight;
            size_t uv_size = y_size / 2;
            mConsumer->ReadRAWFrame(mBufferId, (u16)FORMAT_YUV, mFrameContainer);
            // Ensure that Y and UV addresses are valid
            if (!mFrameContainer->y_addr)
            {
                LOG_ERROR("Error: Invalid Y address in frame container.");
                return -1;
            }
            // Copy the Y component into the buffer
            std::memcpy(buffer, mFrameContainer->y_addr, y_size);

            // Copy the UV component into the buffer if it exists
            if (mFrameContainer->uv_addr)
            {
                std::memcpy(buffer + y_size, mFrameContainer->uv_addr, uv_size);
            }
            else
            {
                LOG_INFO("Warning: UV component is missing in the frame.");
                std::memset(buffer + y_size, 0, uv_size);
            }
            return static_cast<uint64_t>(mFrameContainer->mono_pts);
        }

        uint64_t YUVFrameReader::readFrame()
        {
            // Ensure that mFrameContainer contains valid Y and UV addresses
            mConsumer->ReadRAWFrame(mBufferId, (u16)FORMAT_YUV, mFrameContainer);

            if (!mFrameContainer->y_addr)
            {
                LOG_ERROR("Error: Invalid Y address in frame container.");
                return -1;
            }
            if (!mFrameContainer->uv_addr)
            {
                LOG_ERROR("Error: Invalid UV address in frame container.");
                return -1;
            }

            // Assign the Y and UV addresses to the std::pair
            mRawFrame.first = mFrameContainer->y_addr;   // Y buffer
            mRawFrame.second = mFrameContainer->uv_addr; // UV buffer

            return static_cast<uint64_t>(mFrameContainer->mono_pts);
        }

        frameInfoYUV *YUVFrameReader::CaptureFrameFromCamera()
        {
            mConsumer->ReadRAWFrame(mBufferId, (u16)FORMAT_YUV, mFrameContainer);
            return mFrameContainer;
        }
        bool YUVFrameReader::initBoundingBoxOverlay()
        {
            return mConsumer->InitBoundingBoxOverlay() == XSTREAMER_SUCCESS;
        }

        bool YUVFrameReader::drawBoundingBox(int streamId, int area, int x, int y, int width, int height, int color)
        {
            return mConsumer->drawBoundingBox(streamId, area, x, y, width, height, color) == XSTREAMER_SUCCESS;
        }

        bool YUVFrameReader::deleteBoundingBox(int streamId, int area)
        {
            return mConsumer->deleteBoundingBox(streamId, area) == XSTREAMER_SUCCESS;
        }

        bool YUVFrameReader::initTextOverlay()
        {
            return mConsumer->InitTextOverlay() == XSTREAMER_SUCCESS;
        }

        bool YUVFrameReader::drawText(int streamId, int area, int x, int y, int width, int height, int color, const std::string &text)
        {
            return mConsumer->drawText(streamId, area, x, y, width, height, color, text) == XSTREAMER_SUCCESS;
        }

        bool YUVFrameReader::deleteText(int streamId, int area)
        {
            return mConsumer->deleteText(streamId, area) == XSTREAMER_SUCCESS;
        }
    } // namespace camera_ml
} // namespace camera
