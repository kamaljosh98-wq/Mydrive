// Unified NetworkFrameReader.cpp supporting both H264 and YUV
#include "NetworkFrameReader.hpp"
#include "CurlHttpClient.hpp"
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <arpa/inet.h>
#include <chrono>
#include <thread>
#include <iomanip>

#ifndef AV_CODEC_FLAG_TRUNCATED
#define AV_CODEC_FLAG_TRUNCATED 0x00010000
#endif

namespace camera
{
    namespace camera_ml
    {
        NetworkFrameReader::NetworkFrameReader(const std::string &url, int width, int height, FrameFormat format)
            : client(std::make_shared<CurlHttpClient>()), connectionEstablished(false), frameFormat(format)
        {
            this->url = url;
            mWidth = width;
            mHeight = height;
            mRawFrame.first = nullptr;
            mRawFrame.second = nullptr;

            if (frameFormat == FrameFormat::FF_H264)
            {
                uint32_t y_size = mWidth * mHeight;
                uint32_t uv_size = (mWidth / 2) * (mHeight / 2) * 2;
                mRawFrame.first = new uint8_t[y_size];
                mRawFrame.second = new uint8_t[uv_size];
            }
	    else if (frameFormat == FrameFormat::FF_YUV)
	    {
                mWidth = 0; // update the width once we read the YUV frame
		mHeight = 0; // update the height once we read the YUV frame
	    }

            std::string startStreamUrl = url + "/start_stream/2" + "?width=" + std::to_string(width) + "&height=" + std::to_string(height);
            if (client->connect(startStreamUrl))
            {
                std::cout << "Stream connection established successfully." << std::endl;
                connectionEstablished = true;
            }
            else
            {
                std::cerr << "Failed to establish stream connection." << std::endl;
                connectionEstablished = false;
            }

            if (frameFormat == FrameFormat::FF_H264)
                initFFmpegDecoder();
        }

        NetworkFrameReader::~NetworkFrameReader()
        {
            if (mRawFrame.first) delete[] mRawFrame.first;
            if (mRawFrame.second) delete[] mRawFrame.second;
            if (frameFormat == FrameFormat::FF_H264)
                cleanupFFmpegDecoder();
        }

        void NetworkFrameReader::initFFmpegDecoder()
        {
            const AVCodec *codec = avcodec_find_decoder(AV_CODEC_ID_H264);
            codecCtx = avcodec_alloc_context3(codec);
            if (!codec || !codecCtx)
            {
                std::cerr << "Failed to allocate H264 codec or context." << std::endl;
                return;
            }
            codecCtx->pix_fmt = AV_PIX_FMT_YUV420P;
            codecCtx->flags |= AV_CODEC_FLAG_TRUNCATED;
            parserCtx = av_parser_init(codec->id);
            if (!parserCtx)
            {
                std::cerr << "Failed to initialize parser." << std::endl;
                return;
            }
            codecCtx->color_range = AVCOL_RANGE_MPEG;
            if (avcodec_open2(codecCtx, codec, nullptr) < 0)
            {
                std::cerr << "Failed to open codec." << std::endl;
                return;
            }
            avFrame = av_frame_alloc();
            avPacket = av_packet_alloc();
        }

        void NetworkFrameReader::cleanupFFmpegDecoder()
        {
            av_frame_free(&avFrame);
            av_packet_free(&avPacket);
            av_parser_close(parserCtx);
            avcodec_free_context(&codecCtx);
        }

        bool NetworkFrameReader::decodeH264Frame(const uint8_t *data, size_t size)
        {
            std::cerr << "decodeH264Frame: i/p size->" << size << std::endl;
            av_packet_unref(avPacket);
            av_init_packet(avPacket);
            avPacket->data = const_cast<uint8_t *>(data);
            avPacket->size = static_cast<int>(size);
            int ret = avcodec_send_packet(codecCtx, avPacket);
            if (ret < 0)
            {
                char errbuf[AV_ERROR_MAX_STRING_SIZE];
                av_strerror(ret, errbuf, sizeof(errbuf));
                std::cerr << "avcodec_send_packet failed: " << errbuf << std::endl;
                return false;
            }
            bool gotFrame = false;
            while (true)
            {
                ret = avcodec_receive_frame(codecCtx, avFrame);
                if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
                    break;
                if (ret < 0)
                {
                    char errbuf[AV_ERROR_MAX_STRING_SIZE];
                    av_strerror(ret, errbuf, sizeof(errbuf));
                    std::cerr << "avcodec_receive_frame failed: " << errbuf << std::endl;
                    return false;
                }
                gotFrame = true;
                if (avFrame->color_range == AVCOL_RANGE_UNSPECIFIED)
                    avFrame->color_range = AVCOL_RANGE_MPEG;
                bool needsResize = (avFrame->width != mWidth || avFrame->height != mHeight);
                bool needsFormatConvert = (avFrame->format != AV_PIX_FMT_YUV420P);
                AVFrame *outputFrame = avFrame;
                SwsContext *swsCtx = nullptr;
                uint8_t *yuv_buffer = nullptr;
                if (needsResize || needsFormatConvert)
                {
                    outputFrame = av_frame_alloc();
                    int y_size = mWidth * mHeight;
                    int uv_size = (mWidth / 2) * (mHeight / 2);
                    yuv_buffer = new uint8_t[y_size + 2 * uv_size];
                    av_image_fill_arrays(outputFrame->data, outputFrame->linesize,
                                        yuv_buffer, AV_PIX_FMT_YUV420P, mWidth, mHeight, 1);
                    swsCtx = sws_getContext(
                        avFrame->width, avFrame->height, (AVPixelFormat)avFrame->format,
                        mWidth, mHeight, AV_PIX_FMT_YUV420P,
                        SWS_BICUBIC, nullptr, nullptr, nullptr);
                    if (!swsCtx)
                    {
                        std::cerr << "Failed to create SwsContext" << std::endl;
                        av_frame_free(&outputFrame);
                        delete[] yuv_buffer;
                        return false;
                    }
                    sws_scale(swsCtx, avFrame->data, avFrame->linesize, 0, avFrame->height,
                              outputFrame->data, outputFrame->linesize);
                }
                int y_size = mWidth * mHeight;
                memcpy(mRawFrame.first, outputFrame->data[0], y_size);
                for (int i = 0; i < mHeight / 2; ++i)
                {
                    for (int j = 0; j < mWidth / 2; ++j)
                    {
                        mRawFrame.second[i * mWidth + 2 * j] = outputFrame->data[1][i * outputFrame->linesize[1] + j];
                        mRawFrame.second[i * mWidth + 2 * j + 1] = outputFrame->data[2][i * outputFrame->linesize[2] + j];
                    }
                }
                if (swsCtx)
                    sws_freeContext(swsCtx);
                if (outputFrame != avFrame)
                    av_frame_free(&outputFrame);
                if (yuv_buffer)
                    delete[] yuv_buffer;
                break;
            }
            if (!gotFrame)
            {
                std::cerr << "No frame decoded from packet (decoder needs more data?)" << std::endl;
                return false;
            }
            return true;
        }

        uint64_t NetworkFrameReader::readFrame(uint8_t *buffer)
        {
            uint64_t timestamp = readFrame();
            if (timestamp != static_cast<uint64_t>(-1))
            {
                memcpy(buffer, mRawFrame.first, mWidth * mHeight);
                memcpy(buffer + mWidth * mHeight, mRawFrame.second, (mWidth / 2) * (mHeight / 2) * 2);
            }
            return timestamp;
        }

        uint64_t NetworkFrameReader::readFrame()
        {
            if (!connectionEstablished)
            {
                std::cerr << "Stream connection not established." << std::endl;
                return static_cast<uint64_t>(-1);
            }

            std::string requestFrameUrl = url + "/request_frame/2";
            int maxRetries = 3;
            int retryCount = 0;
            int retryDelayMs = 100;
            while (retryCount < maxRetries)
            {
                if (client->downloadData(requestFrameUrl))
                    break;
                std::cerr << "Failed to retrieve frame data from server. Retrying in " << retryDelayMs << " ms..." << std::endl;
                retryCount++;
                std::this_thread::sleep_for(std::chrono::milliseconds(retryDelayMs));
            }
            if (retryCount == maxRetries)
            {
                std::cerr << "Failed to retrieve frame data from server after retries." << std::endl;
                return static_cast<uint64_t>(-1);
            }

            std::string responseData = client->getResponseData();
            if (responseData.size() < 18)
            {
                std::cerr << "Incomplete header data received" << std::endl;
                return static_cast<uint64_t>(-1);
            }

            uint32_t new_width = ntohl(*reinterpret_cast<const uint32_t *>(&responseData[0]));
            uint32_t new_height = ntohl(*reinterpret_cast<const uint32_t *>(&responseData[4]));
            uint32_t frame_size = ntohl(*reinterpret_cast<const uint32_t *>(&responseData[8]));
            float frame_rate;
            {
                uint32_t net_fps;
                std::memcpy(&net_fps, &responseData[12], sizeof(net_fps));
                net_fps = ntohl(net_fps);
                std::memcpy(&frame_rate, &net_fps, sizeof(frame_rate));
            }
            bool first_frame = static_cast<bool>(responseData[16]);
            bool last_frame = static_cast<bool>(responseData[17]);
            std::cerr << "Parsed header - Width: " << new_width
                      << ", Height: " << new_height
                      << ", Frame Size: " << frame_size
                      << ", FPS: " << frame_rate
                      << ", First: " << first_frame
                      << ", Last: " << last_frame
                      << ", Payload length: " << responseData.size() << std::endl;

            if (first_frame)
                std::cout << "First frame of the clip received." << std::endl;
            if (last_frame)
                std::cout << "Last frame of the clip received." << std::endl;

            if (frameFormat == FrameFormat::FF_H264)
            {
                if (responseData.size() < 18 + frame_size)
                {
                    std::cerr << "Incomplete H.264 data! Expected total: " << (18 + frame_size)
                              << ", got: " << responseData.size() << std::endl;
                    return static_cast<uint64_t>(-1);
                }
                const uint8_t *frameData = reinterpret_cast<const uint8_t *>(&responseData[18]);
                if (!decodeH264Frame(frameData, frame_size))
                {
                    std::cerr << "H264 decoding failed" << std::endl;
                    return static_cast<uint64_t>(-1);
                }
            }
            else if (frameFormat == FrameFormat::FF_YUV)
            {
                if (new_width != mWidth || new_height != mHeight)
                {
                    mWidth = new_width;
                    mHeight = new_height;
                    uint32_t y_size = mWidth * mHeight;
                    uint32_t uv_size = (mWidth / 2) * (mHeight / 2) * 2;
                    if (mRawFrame.first) delete[] mRawFrame.first;
                    if (mRawFrame.second) delete[] mRawFrame.second;
                    mRawFrame.first = new uint8_t[y_size];
                    mRawFrame.second = new uint8_t[uv_size];
                }
                uint32_t y_size = mWidth * mHeight;
                uint32_t uv_size = (mWidth / 2) * (mHeight / 2) * 2;
                uint32_t expected_size = y_size + uv_size;
                if (responseData.size() < 18 + frame_size || frame_size != expected_size)
                {
                    std::cerr << "Incomplete frame data received" << std::endl;
                    return static_cast<uint64_t>(-1);
                }
                memcpy(mRawFrame.first, &responseData[18], y_size);
                memcpy(mRawFrame.second, &responseData[18 + y_size], uv_size);
            }
            return static_cast<uint64_t>(time(nullptr));
        }
    }
}

