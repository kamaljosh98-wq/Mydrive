#include "CameraFrameReader.hpp"

CameraFrameReader::CameraFrameReader(int cameraId, int width, int height)
    : mWidth(width), mHeight(height), mCameraId(cameraId)
{
    mCap.open(0); // Open default camera
    if (!mCap.isOpened())
    {
        throw std::runtime_error("Failed to open the camera.");
    }
    mCap.set(cv::CAP_PROP_FRAME_WIDTH, mWidth);
    mCap.set(cv::CAP_PROP_FRAME_HEIGHT, mHeight);
}

CameraFrameReader::~CameraFrameReader()
{
    mCap.release();
}

bool CameraFrameReader::readFrame(uint8_t *buffer)
{
    cv::Mat frame;
    if (!mCap.read(frame))
    {
        return false; // Failed to read frame
    }

    cv::Mat yuvFrame;
    cv::cvtColor(frame, yuvFrame, cv::COLOR_BGR2YUV_I420);
    memcpy(buffer, yuvFrame.data, mWidth * mHeight * 3 / 2);
    return true;
}

int CameraFrameReader::getWidth() const
{
    return mWidth;
}

int CameraFrameReader::getHeight() const
{
    return mHeight;
}
