#ifndef __CAMERAFRAMEHANDLER_H__
#define __CAMERAFRAMEHANDLER_H__
#include <cstdint>
#include <iostream>
#include <vector>
#include <memory>
#include <algorithm> // For std::min and std::max
#include <opencv2/opencv.hpp>
#include "MotionEventMetadata.hpp"
#include "Logger.hpp"

namespace camera
{
    namespace camera_ml
    {
        typedef struct NormalizationParams
        {
            float scale;
            int zeroPoint;
            float uBound;
            float lBound;
            int inputWidth;
            int inputHeight;
            int noOfChannels;
            void print() const
            {
                std::cout << "Scale: " << scale << std::endl;
                std::cout << "Zero Point: " << zeroPoint << std::endl;
                std::cout << "Upper Bound: " << uBound << std::endl;
                std::cout << "Lower Bound: " << lBound << std::endl;
                std::cout << "Input Width: " << inputWidth << std::endl;
                std::cout << "Input Height: " << inputHeight << std::endl;
                std::cout << "Number of Channels: " << noOfChannels << std::endl;
            }
        } NormalizationParams;

        class CameraFrameHandler
        {
        public:
            std::shared_ptr<uint8_t[]> convertAndResize(uint8_t *raw, int width, int height, int newWidth, int newHeight, BoundingBox unionBox = BoundingBox());
            std::shared_ptr<uint8_t[]> normalizeAndResize(uint8_t *raw, int width, int height, NormalizationParams params, BoundingBox unionBox = BoundingBox());
            std::shared_ptr<uint8_t[]> resizeNormalizeQuantize(uint8_t *raw, int width, int height, NormalizationParams params, BoundingBox unionBox = BoundingBox());
            ScalingParams convertAndStore(uint8_t *raw, int width, int height, int newWidth, int newHeight, const std::string &filePath, BoundingBox unionBox = BoundingBox());
            void saveBufferAsJpeg(uint8_t *buffer, int width, int height, const std::string &filePath);
            void saveRGBBufferAsJPEG(const uint8_t *buffer, int width, int height, const std::string &filename);
            void saveYUVBufferAsJpeg(uint8_t *yBuffer, uint8_t *uvBuffer, int width, int height, const std::string &filePath);
        private:
            cv::Mat convertYUVToRGB(uint8_t *raw, int width, int height);
            ScalingParams resizeFrame(cv::Mat &inputFrame, cv::Mat &outputFrame, int newWidth, int newHeight, BoundingBox unionBox);
            void normalizeFrame(cv::Mat &inputFrame, cv::Mat &outputFrame);
            void quantizeFrame(cv::Mat &inputFrame, cv::Mat &outputFrame, NormalizationParams params);
            std::shared_ptr<uint8_t[]> allocateAndCopy(cv::Mat &frame);
            static cv::Point2f getActualCentroid(cv::Rect boundRect);
            static cv::Point2f alignCentroid(cv::Point2f orgCenter, cv::Mat origFrame, cv::Size cropSize);
            static cv::Rect getRelativeBoundingBox(cv::Rect boundRect, cv::Size cropSize, cv::Point2f allignedCenter);
            static cv::Size getResizedCropSize(cv::Rect boundRect, int w, int h, double *resizeScale);
        };
    }
}
#endif // __CAMERAFRAMEHANDLER_H__
