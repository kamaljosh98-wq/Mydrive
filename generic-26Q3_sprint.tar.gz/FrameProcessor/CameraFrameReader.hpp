#ifndef CAMERAFRAMEREADER_HPP
#define CAMERAFRAMEREADER_HPP

#include "FrameReader.hpp"

class CameraFrameReader : public FrameReader {
public:
    CameraFrameReader(int cameraId, int width, int height);
    ~CameraFrameReader() override;
    uint64_t readFrame(uint8_t* buffer) override;

private:
    cv::VideoCapture cap_;
    int mCameraId;
};

#endif // CAMERAFRAMEREADER_HPP
