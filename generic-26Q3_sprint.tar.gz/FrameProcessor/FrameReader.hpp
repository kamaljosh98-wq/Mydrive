#ifndef FRAMEREADER_HPP
#define FRAMEREADER_HPP

#include <cstdint> // Include for uint8_t, uint32_t, uint64_t
#include <utility> // Include for std::pair
#include <cstring>
#include <iostream>
#include <memory>


namespace camera
{
    namespace camera_ml
    {
        /**
         * @brief Abstract base class for reading frames.
         *
         * This class provides an interface for reading frames into a buffer. It includes methods
         * for reading a frame, getting the width and height of the frame, and a destructor.
         */
        class FrameReader
        {
        public:
            FrameReader() : mWidth(0), mHeight(0), mRawFrame(nullptr, nullptr) {}
            virtual ~FrameReader() = default;

            /**
             * @brief Reads a frame into the provided buffer.
             *
             * This method attempts to read a frame into the given buffer. If successful, it returns
             * the monotonic timestamp (mono_ts) of the frame. If the frame cannot be read or if an error
             * occurs, it returns -1.
             *
             * @param buffer A pointer to the buffer where the frame data will be written.
             *               The buffer should have enough space to hold the frame data.
             *
             * @return int64_t Returns the monotonic timestamp of the frame (mono_ts) on success,
             *         or -1 if the frame cannot be read or an error occurs.
             */
            virtual uint64_t readFrame(uint8_t *buffer) = 0;

            /**
             * @brief Reads the Y and UV frames into internal buffers.
             *
             * This method reads Y and UV frames into internal buffers (`mRawFrame`). The frame can be
             * accessed later using `getYBuffer()` and `getUVBuffer()`.
             *
             * @return uint64_t Returns the monotonic timestamp of the frame (mono_ts) on success,
             *         or -1 if the frame cannot be read or an error occurs.
             */
            virtual uint64_t readFrame() = 0;

            // Get the width of the frame
            int getWidth()
            {
                return mWidth;
            }

            // Get the height of the frame
            int getHeight()
            {
                return mHeight;
            }

            // Get the Y buffer (luminance)
            uint8_t *getYBuffer()
            {
                return mRawFrame.first;
            }

            // Get the UV buffer (chrominance)
            uint8_t *getUVBuffer()
            {
                return mRawFrame.second;
            }

        protected:
	    // The width of the frame
            uint32_t mWidth;

	    // The height of the frame
            uint32_t mHeight;

	    // Class variable to hold Y and UV buffer pointers
            std::pair<uint8_t *, uint8_t *> mRawFrame;
        };
    } // namespace camera_ml
} // namespace camera
#endif // FRAMEREADER_HPP
