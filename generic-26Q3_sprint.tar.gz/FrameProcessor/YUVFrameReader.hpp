#ifndef YUVFRAMEREADER_HPP
#define YUVFRAMEREADER_HPP

/**
 * @class YUVFrameReader
 * @brief A class that reads frames from a buffer.
 *
 * This class provides functionality to read frames from a buffer identified by a buffer ID.
 * It uses an XStreamerConsumer to consume frames and stores the frame information in a frameInfoYUV container.
 */
#include "FrameReader.hpp"
#include "xStreamerConsumer.h"
#include "Logger.hpp"
#include <iostream>
namespace camera
{
    namespace camera_ml
    {
        class YUVFrameReader : public FrameReader
        {
        public:
            /**
             * @brief Constructs a YUVFrameReader object with the specified buffer ID.
             *
             * @param bufferId The ID of the buffer.
             */
            YUVFrameReader(u16 bufferId);
            /**
             * @brief Reads a frame into the provided buffer.
             *
             * This method attempts to read a frame from the frame source and stores the data
             * in the given buffer. If the frame is read successfully, it returns the monotonic
             * timestamp (mono_ts) of the frame. If there is an error, such as failing to read
             * the frame or invalid buffer input, the method returns -1.
             *
             * @param buffer A pointer to the buffer where the frame data will be written.
             *               The buffer must have sufficient space to accommodate the frame data.
             *
             * @return int64_t Returns the monotonic timestamp of the frame (mono_ts) on success,
             *         or -1 if the frame cannot be read or an error occurs.
             */

            uint64_t readFrame(uint8_t *buffer) override;

             /**
             * @brief Reads the Y and UV frames into internal buffers.
             *
             * This method reads Y and UV frames into internal buffers (`mRawFrame`). The frame can be
             * accessed later using `getYBuffer()` and `getUVBuffer()`.
             *
             * @return uint64_t Returns the monotonic timestamp of the frame (mono_ts) on success,
             *         or -1 if the frame cannot be read or an error occurs.
             */

            uint64_t readFrame() override;
          
            frameInfoYUV *CaptureFrameFromCamera();
            // Bounding box overlay functionality
            bool initBoundingBoxOverlay();
            bool drawBoundingBox(int streamId, int area, int x, int y, int width, int height, int color);
            bool deleteBoundingBox(int streamId, int area);

            // Text overlay functionality
            bool initTextOverlay();
            bool drawText(int streamId, int area, int x, int y, int width, int height, int color, const std::string &text);
            bool deleteText(int streamId, int area);

        private:
            u16 mBufferId;
            std::unique_ptr<XStreamerConsumer> mConsumer;
            frameInfoYUV *mFrameContainer;
        };
    } // namespace camera_ml
} // namespace camera
#endif // YUVFRAMEREADER_HPP