#ifndef NETWORKFRAMEREADER_HPP
#define NETWORKFRAMEREADER_HPP

#include "FrameReader.hpp"
#include "CurlHttpClient.hpp"
#include <string>
#include <memory>

// Include FFmpeg headers for H264 decoding
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavutil/imgutils.h>
}

namespace camera
{
    namespace camera_ml
    {
// Enum to specify the frame format
        enum class FrameFormat
        {
            FF_H264,
            FF_YUV
        };

        class NetworkFrameReader : public FrameReader
        {
        public:
            // Constructor to initialize the NetworkFrameReader and connect to the server
            NetworkFrameReader(const std::string &url, int width = 640, int height = 480,
			    FrameFormat format = FrameFormat::FF_H264);

            // Destructor to release the resources
            ~NetworkFrameReader() override;

            // Reads the YUV frame from the network into the provided buffer
            uint64_t readFrame(uint8_t *buffer) override;

            // Reads the YUV frame from the network into the internal buffer
            uint64_t readFrame() override;

        private:
	    // URL of the server from which the YUV frames are downloaded
            std::string url;

	    // CurlHttpClient used for HTTP requests
            std::shared_ptr<CurlHttpClient> client;

	    // Flag indicating whether the connection to the server is established
            bool connectionEstablished;

	    // Selected frame format
            FrameFormat frameFormat;

            // FFmpeg decoding context
            AVCodecContext* codecCtx = nullptr;
            AVCodecParserContext* parserCtx = nullptr;
            AVFrame* avFrame = nullptr;
            AVPacket* avPacket = nullptr;
            SwsContext* swsCtx = nullptr;

            void initFFmpegDecoder();
            void cleanupFFmpegDecoder();
            bool decodeH264Frame(const uint8_t* data, size_t size);
        };
    }
}
#endif // NETWORKFRAMEREADER_HPP

