#include "FileFrameReader.hpp"

FileFrameReader::FileFrameReader(const std::string &filePath)
{
    mCap.open(filePath); // Open the video file
    if (!mCap.isOpened())
    {
        throw std::runtime_error("Failed to open the video file: " + filePath);
    }

    mWidth = static_cast<int>(mCap.get(cv::CAP_PROP_FRAME_WIDTH));
    mHeight = static_cast<int>(mCap.get(cv::CAP_PROP_FRAME_HEIGHT));
}

FileFrameReader::~FileFrameReader()
{
    mCap.release();
}

uint64_t FileFrameReader::readFrame(uint8_t *buffer)
{
    cv::Mat frame;
    if (!mCap.read(frame))
    {
        return -1; // End of video or failed to read frame
    }

    cv::Mat yuvFrame;
    cv::cvtColor(frame, yuvFrame, cv::COLOR_BGR2YUV_I420);
    memcpy(buffer, yuvFrame.data, mWidth * mHeight * 3 / 2);
    return 101;
}

int FileFrameReader::getWidth() const
{
    return mWidth;
}

int FileFrameReader::getHeight() const
{
    return mHeight;
}
